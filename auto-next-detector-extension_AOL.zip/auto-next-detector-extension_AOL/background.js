const WATCHDOG_ALARM = 'auto-next-detector-watchdog';
const ENABLED_TABS_KEY = 'autoNextDetectorEnabledTabsV2';
let tabStateMutationQueue = Promise.resolve();

function errorText(error) {
  return String(error?.message || error || 'Unknown extension error');
}

function isExpectedTransientError(error) {
  return /receiving end does not exist|could not establish connection|message port closed|asynchronous response.*channel closed|extension context invalidated|context invalidated|no tab with id|tab was closed|frame with id .* was removed|document unloaded|target closed|back.?forward cache|page.*discarded|network error|failed to fetch|load failed|interrupted|operation was aborted|aborted|disconnected|connection.*closed|user aborted/i.test(errorText(error));
}

function quietUnexpected(context, error) {
  if (!isExpectedTransientError(error)) {
    console.warn(`[Auto Next Detector] ${context}: ${errorText(error)}`);
  }
}

self.addEventListener('unhandledrejection', event => {
  // Chrome may tear down a sender/receiver during fast LMS navigation or sleep/wake.
  // Consume that known transient lifecycle rejection so it does not become a persistent
  // extension error card. Unexpected rejections are logged and the watchdog remains live.
  const reason = event?.reason;
  event.preventDefault();
  quietUnexpected('recovered unhandled rejection', reason);
  void ensureWatchdogAlarm();
});

self.addEventListener('error', event => {
  const error = event?.error || event?.message;
  if (!isExpectedTransientError(error)) return;
  event.preventDefault();
  void ensureWatchdogAlarm();
});

async function playStartActivityAlarm(activityType) {
  // v2.1.4 is intentionally audio-free. Returning ok keeps old content-script
  // requests compatible without creating AudioContext/offscreen playback errors
  // after sleep, hibernation, lid close, or network reconnect.
  return { ok: true, muted: true, audioRemoved: true, activityType: activityType || 'activity' };
}

async function readEnabledTabIds() {
  try {
    const data = await chrome.storage.session.get(ENABLED_TABS_KEY);
    const ids = data?.[ENABLED_TABS_KEY];
    return Array.isArray(ids) ? [...new Set(ids.filter(Number.isInteger))] : [];
  } catch (error) {
    quietUnexpected('read enabled tabs', error);
    return [];
  }
}

async function writeEnabledTabIds(ids) {
  try {
    const uniqueIds = [...new Set((ids || []).filter(Number.isInteger))];
    await chrome.storage.session.set({ [ENABLED_TABS_KEY]: uniqueIds });
    return uniqueIds;
  } catch (error) {
    quietUnexpected('write enabled tabs', error);
    return [];
  }
}

function mutateEnabledTabs(mutator) {
  const operation = tabStateMutationQueue.then(async () => {
    const current = await readEnabledTabIds();
    const next = mutator(current);
    return writeEnabledTabIds(next);
  });

  // Keep the queue usable even if an unexpected Chrome API failure occurs.
  tabStateMutationQueue = operation.then(() => undefined, () => undefined);
  return operation.catch(error => {
    quietUnexpected('enabled-tab state update', error);
    return [];
  });
}

async function setTabEnabled(tabId, enabled) {
  if (!Number.isInteger(tabId)) return false;
  const ids = await mutateEnabledTabs(current => enabled
    ? [...current, tabId]
    : current.filter(id => id !== tabId));
  return enabled ? ids.includes(tabId) : !ids.includes(tabId);
}

async function isTabEnabled(tabId) {
  if (!Number.isInteger(tabId)) return false;
  // Wait for any in-flight state mutation so QUERY_TAB cannot read stale state.
  await tabStateMutationQueue.catch(() => {});
  const ids = await readEnabledTabIds();
  return ids.includes(tabId);
}

async function ensureWatchdogAlarm() {
  try {
    const existing = await chrome.alarms.get(WATCHDOG_ALARM);
    if (!existing) {
      await chrome.alarms.create(WATCHDOG_ALARM, { periodInMinutes: 0.5 });
    }
    return true;
  } catch (error) {
    quietUnexpected('watchdog alarm setup', error);
    return false;
  }
}

async function safeSendTabMessage(tabId, payload) {
  if (!Number.isInteger(tabId)) return null;
  try {
    return await chrome.tabs.sendMessage(tabId, payload);
  } catch (error) {
    // Navigation, sleep/wake, protected pages, and tab teardown can temporarily leave
    // no content-script receiver. This is expected and the next watchdog/content page
    // restores the connection.
    if (!isExpectedTransientError(error)) quietUnexpected('watchdog tab message', error);
    return null;
  }
}

async function handleWatchdogAlarm(alarm) {
  if (alarm?.name !== WATCHDOG_ALARM) return;
  const ids = await readEnabledTabIds();
  if (!ids.length) return;
  await Promise.all(ids.map(tabId => safeSendTabMessage(tabId, {
    type: 'AUTO_NEXT_DETECTOR_WATCHDOG_TICK'
  })));
}

function respondAsync(sendResponse, task, fallback) {
  Promise.resolve(task)
    .then(value => {
      try {
        sendResponse(value);
      } catch (error) {
        // The requesting frame may have navigated away. This is a normal lifecycle race.
      }
    })
    .catch(error => {
      quietUnexpected('message handler', error);
      try {
        sendResponse(typeof fallback === 'function' ? fallback(error) : fallback);
      } catch (sendError) {}
    });
  return true;
}

void ensureWatchdogAlarm();
chrome.runtime.onInstalled.addListener(() => { void ensureWatchdogAlarm(); });
chrome.runtime.onStartup.addListener(() => { void ensureWatchdogAlarm(); });
chrome.runtime.onSuspend?.addListener?.(() => {
  void ensureWatchdogAlarm();
});
chrome.runtime.onSuspendCanceled?.addListener?.(() => {
  void ensureWatchdogAlarm();
});

chrome.alarms.onAlarm.addListener(alarm => {
  void handleWatchdogAlarm(alarm).catch(error => quietUnexpected('watchdog run', error));
});

chrome.tabs.onRemoved.addListener(tabId => {
  void setTabEnabled(tabId, false);
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  try {
    if (!msg || typeof msg.type !== 'string') return false;
    const tabId = sender.tab?.id;

    if (msg.type === 'AUTO_NEXT_DETECTOR_PLAY_START_ACTIVITY_ALARM') {
      return respondAsync(
        sendResponse,
        playStartActivityAlarm(msg.activityType),
        () => ({ ok: false, error: 'Alarm playback failed' })
      );
    }

    if (msg.type === 'AUTO_NEXT_DETECTOR_REGISTER_TAB') {
      return respondAsync(
        sendResponse,
        setTabEnabled(tabId, true).then(ok => ({ ok })),
        { ok: false }
      );
    }

    if (msg.type === 'AUTO_NEXT_DETECTOR_UNREGISTER_TAB') {
      return respondAsync(
        sendResponse,
        setTabEnabled(tabId, false).then(ok => ({ ok })),
        { ok: false }
      );
    }

    if (msg.type === 'AUTO_NEXT_DETECTOR_QUERY_TAB') {
      return respondAsync(
        sendResponse,
        isTabEnabled(tabId).then(enabled => ({ ok: true, enabled })),
        { ok: false, enabled: false }
      );
    }

    return false;
  } catch (error) {
    quietUnexpected('runtime message dispatch', error);
    try { sendResponse({ ok: false, error: 'Temporary extension communication error' }); } catch (sendError) {}
    return false;
  }
});
