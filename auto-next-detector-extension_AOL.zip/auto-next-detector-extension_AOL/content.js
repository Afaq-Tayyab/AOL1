(() => {
  if (window.__autoNextDetectorLoaded) return;
  window.__autoNextDetectorLoaded = true;

  const EXTENSION_VERSION = '2.1.7';
  const CHECK_MS = 250;
  const SCROLL_STEP_PX = 700;
  const LONG_PAUSE_MS = 12000;
  const CLICK_COOLDOWN_MS = 4500;
  const SAME_TARGET_REPEAT_MS = 20000;
  const CLICK_NAVIGATION_VERIFY_MS = 1800;
  const CLICK_HARD_RETRY_LIMIT_MS = 9000;
  const SESSION_ENABLED_KEY = 'autoNextDetectorEnabled';
  const SESSION_MANUAL_PAUSED_KEY = 'autoNextDetectorManualPaused';
  const SESSION_OVERLAY_GEOMETRY_KEY = 'autoNextDetectorOverlayGeometryV1';
  const SESSION_FINAL_EXAM_SUBMIT_PENDING_KEY = 'autoNextDetectorFinalExamSubmitPending';
  const SESSION_ACTIVITY_METADATA_KEY = 'autoNextDetectorActivityMetadataV2';
  const NEXT_TIMER_ENABLED_KEY = 'autoNextDetectorNextTimerEnabled';
  const NEXT_TIMER_SECONDS_KEY = 'autoNextDetectorNextTimerSeconds';
  const DEFAULT_NEXT_DELAY_MS = 350;
  const MAX_NEXT_TIMER_SECONDS = 2147483;
  const MAX_TIMER_NAVIGATION_BACKDATE_MS = 10 * 60 * 1000;
  const QUIZ_AUTO_SUBMIT_PERCENT = 0.55;
  const QUIZ_NO_START_WARNING_PERCENT = 0.20;
  const SUPPORTED_QUIZ_DURATIONS_MIN = new Set([30, 60, 120, 180]);
  const QUIZ_WARNING_REPEAT_MS = 60000;
  const ACTIVITY_METADATA_MAX_AGE_MS = 6 * 60 * 60 * 1000;
  const FINAL_EXAM_MIN_MONITOR_MS = 3500;

  let enabled = false;
  let manualPaused = false;
  let loopTimer = null;
  let clickTimer = null;
  let clickVerifyTimer = null;
  let lastHardRetryKey = '';
  let lastHardRetryAt = 0;
  let currentlyClicking = false;
  let overlay = null;
  let message = 'Idle';
  let lastTickAt = Date.now();
  let lastUrl = location.href;
  let lastClickedKey = '';
  let lastClickedUrl = '';
  let lastClickAt = 0;
  let lastScrollAt = 0;
  let bottomWaitStartedAt = 0;
  let overlayDragState = null;
  let overlayResizeObserver = null;
  let overlayResponsiveRaf = null;
  let overlayLayoutMode = 'full';
  let overlayAutoFitState = '';
  let overlayAutoFitRaf = null;
  let quizPanel = null;
  let quizDetailsCollapsed = false;
  let nextTimerEnabled = false;
  let nextTimerSeconds = 1;
  let pendingNextClick = null;
  let pageTimerStartedAt = 0;
  let pageTimerSignature = '';
  let pageTimerReason = '';
  let pageTimerLastResetAt = 0;
  let lmsWaitSignature = '';
  let lmsWaitLastSeconds = null;
  let lmsWaitLastSeenAt = 0;
  let startActivityControlPresent = false;
  let pageSuspended = false;
  let consecutiveLoopErrors = 0;
  let lastLoopRecoveryNoticeAt = 0;
  let quizState = createEmptyQuizState();
  let referrerDurationLookup = { key: '', inFlight: false, done: false };
  let activityMetadataCaptureTimer = null;

  function createEmptyQuizState() {
    return {
      active: false,
      key: '',
      title: '',
      activityType: 'quiz',
      startedAt: 0,
      durationMin: null,
      durationSource: '',
      durationScanAt: 0,
      lmsTimerSeen: false,
      lastLmsElapsedSeconds: null,
      lastLmsTimerSeenAt: 0,
      remainingSeconds: null,
      totalQuestions: 0,
      questionCountReliable: false,
      answerStateReliable: false,
      answeredCount: 0,
      missedNumbers: [],
      elapsedSeconds: 0,
      timerSource: '',
      timerStableReads: 0,
      timerProgressReads: 0,
      firstLiveTimerSeenAt: 0,
      lastLiveElapsedSeconds: null,
      lastLiveRemainingSeconds: null,
      lastLiveTimerSeenAt: 0,
      timeRunningDirection: '',
      timeRunningDirectionCandidate: '',
      timeRunningDirectionReads: 0,
      lastTimeRunningRawSeconds: null,
      lastTimeRunningRawSeenAt: 0,
      monitorStartedAt: 0,
      lastProgressAt: 0,
      lastProgressElapsedSeconds: 0,
      lastAnsweredCount: 0,
      noStartWarningSent: false,
      lastStallWarningAt: 0,
      autoSubmitInFlight: false,
      autoSubmitAttempted: false,
      autoSubmitAttemptedAt: 0,
      submittedByAuto: false,
      statusNote: ''
    };
  }

  function errorText(error) {
    return String(error?.message || error || 'Unknown error');
  }

  function isExpectedTransientError(error) {
    return /receiving end does not exist|could not establish connection|message port closed|asynchronous response.*channel closed|extension context invalidated|context invalidated|no tab with id|tab was closed|frame with id .* was removed|document unloaded|target closed|back.?forward cache|page.*discarded|network error|failed to fetch|load failed|interrupted|operation was aborted|aborted|disconnected|connection.*closed|user aborted/i.test(errorText(error));
  }

  function recoverAfterLifecycleInterruption(reason = 'lifecycle') {
    pageSuspended = false;
    currentlyClicking = false;
    clearPendingClick();
    lastTickAt = Date.now();
    if (enabled) {
      createOverlay();
      registerEnabledTab();
      if (!manualPaused) {
        updateOverlay(reason === 'online'
          ? 'Auto Next: online again. Resuming detection...'
          : 'Auto Next: browser/network resumed. Re-synchronizing safely...');
        scheduleLoop(250);
      }
    }
  }

  function safeInvoke(label, fn, fallback = undefined) {
    try {
      return fn();
    } catch (error) {
      if (!isExpectedTransientError(error)) {
        console.warn(`[Auto Next Detector] ${label}: ${errorText(error)}`);
      }
      return fallback;
    }
  }

  window.addEventListener('unhandledrejection', event => {
    const reason = event?.reason;
    if (isExpectedTransientError(reason)) {
      event.preventDefault?.();
      recoverAfterLifecycleInterruption('promise-recovery');
    }
  });

  window.addEventListener('error', event => {
    const reason = event?.error || event?.message;
    if (isExpectedTransientError(reason)) {
      event.preventDefault?.();
      recoverAfterLifecycleInterruption('error-recovery');
    }
  });

  function safeRuntimeMessage(payload, callback = null) {
    let settled = false;
    const finish = (response, error = '') => {
      if (settled) return;
      settled = true;
      if (typeof callback === 'function') {
        safeInvoke('runtime message callback', () => callback(response, error));
      }
    };

    try {
      if (!globalThis.chrome?.runtime?.sendMessage) {
        finish(null, 'Extension runtime is temporarily unavailable');
        return;
      }

      const maybePromise = chrome.runtime.sendMessage(payload, response => {
        let lastErrorMessage = '';
        try {
          // Reading runtime.lastError inside the callback deliberately consumes expected
          // navigation/receiver errors instead of leaving an unchecked Chrome error.
          lastErrorMessage = chrome.runtime.lastError?.message || '';
        } catch (error) {
          lastErrorMessage = errorText(error);
        }
        finish(lastErrorMessage ? null : response, lastErrorMessage);
      });

      if (maybePromise && typeof maybePromise.then === 'function') {
        maybePromise
          .then(response => finish(response, ''))
          .catch(error => finish(null, errorText(error)));
      }
    } catch (error) {
      finish(null, errorText(error));
    }
  }


  function clampNextTimerSeconds(value) {
    const parsed = Math.floor(Number(value));
    if (!Number.isFinite(parsed) || parsed < 1) return 1;
    return Math.min(parsed, MAX_NEXT_TIMER_SECONDS);
  }

  function applyNextTimerSetting(enabledValue, secondsValue) {
    nextTimerEnabled = enabledValue === true;
    nextTimerSeconds = clampNextTimerSeconds(secondsValue ?? nextTimerSeconds ?? 1);
  }

  function loadNextTimerSetting() {
    try {
      if (!globalThis.chrome?.storage?.local?.get) return;
      chrome.storage.local.get([NEXT_TIMER_ENABLED_KEY, NEXT_TIMER_SECONDS_KEY], data => {
        try {
          const lastErrorMessage = chrome.runtime?.lastError?.message || '';
          if (!lastErrorMessage) {
            applyNextTimerSetting(data?.[NEXT_TIMER_ENABLED_KEY], data?.[NEXT_TIMER_SECONDS_KEY]);
          }
        } catch (error) {}
      });
    } catch (error) {
      // Default timer OFF is retained if storage is temporarily unavailable.
    }
  }

  function getNextDelayMs() {
    return getNextClickDelayMs(Date.now());
  }

  function nextTimerStatusText() {
    return nextTimerEnabled ? `Timer ON: ${clampNextTimerSeconds(nextTimerSeconds)} sec` : 'Timer OFF';
  }

  function nextTimerCountdownText(now = Date.now()) {
    const secondsLeft = nextTimerCountdownSeconds(now);
    if (secondsLeft === null) return '';
    return `${secondsLeft} sec`;
  }

  function nextTimerCountdownSeconds(now = Date.now()) {
    if (pendingNextClick?.deadline) return Math.max(0, Math.ceil((pendingNextClick.deadline - now) / 1000));
    return nextTimerCountdownFromPageClock(now);
  }

  function nextTimerCountdownLine(now = Date.now()) {
    const secondsLeft = nextTimerCountdownSeconds(now);
    if (secondsLeft === null || !nextTimerEnabled) return '';
    const total = clampNextTimerSeconds(pendingNextClick?.delaySeconds ?? nextTimerSeconds);
    return `Next click countdown: ${secondsLeft} sec remaining / ${total} sec`;
  }

  function getPageTimerDeadlineMs() {
    if (!nextTimerEnabled || !pageTimerStartedAt) return 0;
    return pageTimerStartedAt + (clampNextTimerSeconds(nextTimerSeconds) * 1000);
  }

  function getNextClickDeadline(now = Date.now()) {
    if (!nextTimerEnabled) return now + DEFAULT_NEXT_DELAY_MS;
    const pageDeadline = getPageTimerDeadlineMs();
    return pageDeadline ? Math.max(now, pageDeadline) : now + (clampNextTimerSeconds(nextTimerSeconds) * 1000);
  }

  function getNextClickDelayMs(now = Date.now()) {
    if (!nextTimerEnabled) return DEFAULT_NEXT_DELAY_MS;
    return Math.max(0, getNextClickDeadline(now) - now);
  }

  function nextTimerPageElapsedSeconds(now = Date.now()) {
    if (!pageTimerStartedAt) return 0;
    return Math.max(0, Math.floor((now - pageTimerStartedAt) / 1000));
  }

  function nextTimerCountdownFromPageClock(now = Date.now()) {
    if (!nextTimerEnabled) return null;
    const deadline = getPageTimerDeadlineMs();
    if (!deadline) return null;
    return Math.max(0, Math.ceil((deadline - now) / 1000));
  }

  function shouldShowNextTimerCountdown(now = Date.now()) {
    if (!enabled || manualPaused || !nextTimerEnabled || quizState.active) return false;
    if (pendingNextClick?.deadline && pendingNextClick.deadline > now - 1000) return true;
    const secondsLeft = nextTimerCountdownFromPageClock(now);
    return secondsLeft !== null && secondsLeft > 0;
  }

  function normalizeText(value) {
    return String(value || '')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  }

  function getElementText(el) {
    return normalizeText([
      el.innerText,
      el.textContent,
      el.getAttribute?.('aria-label'),
      el.getAttribute?.('title'),
      el.getAttribute?.('value'),
      el.getAttribute?.('data-tooltip'),
      el.getAttribute?.('data-testid')
    ].filter(Boolean).join(' '));
  }

  function getNavigationStartEpochMs(now = Date.now()) {
    try {
      const origin = Number(performance?.timeOrigin);
      if (Number.isFinite(origin) && origin > 0) return origin;
      const age = Number(performance?.now?.());
      if (Number.isFinite(age) && age >= 0) return now - age;
    } catch (error) {}
    return now;
  }

  function getPrimaryPageHeading() {
    const selectors = ['main h1', '#content h1', '.page-title', 'h1', 'main h2', '#content h2'];
    for (const selector of selectors) {
      try {
        for (const el of document.querySelectorAll(selector)) {
          if (!isVisible(el)) continue;
          const text = String(el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
          if (text) return text.slice(0, 180);
        }
      } catch (error) {}
    }
    return String(document.title || '').split(/\s*[|•]\s*/)[0].trim().slice(0, 180);
  }

  function getPageTimerSignature() {
    // Keep the optional Next timer anchored to the actual LMS route, not to text that
    // can change while a module is counting down (for example: "Wait 8s to continue").
    // Previous builds included the visible heading here; some AOL/Canvas pages re-render
    // headings/labels during the module wait, which restarted the extension timer at 30s.
    return `${location.origin}${location.pathname}${location.search}${location.hash}`;
  }

  function resetPageTimerStart(reason = 'reset', now = Date.now(), useNavigationStart = false) {
    let startedAt = useNavigationStart ? getNavigationStartEpochMs(now) : now;
    // If the browser document is extremely old, avoid treating hours of idle time as
    // completed reading time after the user manually starts the extension. This keeps
    // normal module syncing accurate while preventing accidental instant skips from an
    // old stale tab.
    if (useNavigationStart && now - startedAt > MAX_TIMER_NAVIGATION_BACKDATE_MS) startedAt = now;
    pageTimerStartedAt = startedAt;
    pageTimerSignature = getPageTimerSignature();
    pageTimerReason = reason;
    pageTimerLastResetAt = now;
  }

  function keepPageTimerSyncedToDocumentClock(now = Date.now()) {
    if (!nextTimerEnabled) return;
    const navStart = getNavigationStartEpochMs(now);
    if (!Number.isFinite(navStart) || navStart <= 0) return;
    if (now - navStart > MAX_TIMER_NAVIGATION_BACKDATE_MS) return;

    // The timer must count from the module/page load, even before the Next button is
    // enabled. If the content script, popup start, browser throttling, or AOL re-render
    // made the extension start its own timer late, backdate it to the document clock.
    // Never move the timer forward here; that would add artificial extra wait time.
    if (!pageTimerStartedAt || pageTimerStartedAt - navStart > 750) {
      pageTimerStartedAt = navStart;
      pageTimerSignature = getPageTimerSignature();
      pageTimerReason = 'document-clock-sync';
      pageTimerLastResetAt = now;
      return;
    }

    // Small correction for clock drift after laptop sleep/tab throttling.
    if (navStart < pageTimerStartedAt) pageTimerStartedAt = navStart;
  }

  function ensurePageTimerForCurrentView(now = Date.now()) {
    if (!nextTimerEnabled) {
      if (!pageTimerStartedAt) resetPageTimerStart('timer-off-baseline', now, false);
      return;
    }

    const signature = getPageTimerSignature();
    if (!pageTimerStartedAt) {
      resetPageTimerStart('initial-document-clock-sync', now, true);
      keepPageTimerSyncedToDocumentClock(now);
      return;
    }

    // Only a real route change should restart the module timer. Dynamic LMS text,
    // disabled/enabled Next state, scroll position, and "Wait Ns to continue" updates
    // must not restart the countdown. URL changes are already handled in mainLoopCore.
    if (signature && signature !== pageTimerSignature) {
      clearPendingClick();
      resetPageTimerStart('route-signature-changed', now, false);
      return;
    }

    keepPageTimerSyncedToDocumentClock(now);
  }

  function describeNextTimerSync(now = Date.now()) {
    if (!nextTimerEnabled) return '';
    const elapsed = nextTimerPageElapsedSeconds(now);
    const remaining = Math.max(0, clampNextTimerSeconds(nextTimerSeconds) - elapsed);
    return `Module timer synced: ${elapsed}s already counted, ${remaining}s remaining`;
  }

  function getBodyText() {
    const body = document.body;
    if (!body) return '';

    // Read only LMS page text. Never let values rendered by this extension feed back
    // into question or timer detection if the LMS/browser reparents the overlay.
    let raw = String(body.innerText || body.textContent || '');
    if (overlay && overlay.isConnected) {
      const ownTexts = [overlay.innerText, overlay.textContent]
        .map(value => String(value || '').trim())
        .filter(Boolean)
        .sort((a, b) => b.length - a.length);
      for (const ownText of ownTexts) {
        let index = raw.lastIndexOf(ownText);
        while (index >= 0) {
          raw = `${raw.slice(0, index)} ${raw.slice(index + ownText.length)}`;
          index = raw.lastIndexOf(ownText);
        }
      }
    }
    return normalizeText(raw);
  }


  function detectLmsModuleWait(bodyText = getBodyText()) {
    const body = normalizeText(bodyText || '');
    const result = { active: false, seconds: null, text: '' };
    if (!body) return result;

    const patterns = [
      /\bwait\s+(\d{1,4})\s*(?:s|sec|secs|second|seconds)\s+to\s+continue\b/i,
      /\bwait\s+(\d{1,4})\s*(?:s|sec|secs|second|seconds)\b/i,
      /\bcontinue\s+in\s+(\d{1,4})\s*(?:s|sec|secs|second|seconds)\b/i,
      /\bnext\s+(?:button\s+)?(?:will\s+)?(?:unlock|enable|be\s+available)\s+(?:in|after)\s+(\d{1,4})\s*(?:s|sec|secs|second|seconds)\b/i,
      /\b(\d{1,4})\s*(?:s|sec|secs|second|seconds)\s+(?:remaining\s+)?(?:to\s+continue|before\s+continuing|until\s+next)\b/i
    ];

    for (const pattern of patterns) {
      const match = body.match(pattern);
      if (match) {
        const seconds = Math.max(0, Math.min(9999, parseInt(match[1], 10)));
        if (seconds > 0) {
          result.active = true;
          result.seconds = seconds;
          result.text = match[0];
          lmsWaitSignature = getPageTimerSignature();
          lmsWaitLastSeconds = seconds;
          lmsWaitLastSeenAt = Date.now();
          return result;
        }
      }
    }

    const hasWaitWording = /\b(wait|waiting)\b/.test(body) && /\b(continue|next|proceed)\b/.test(body);
    if (hasWaitWording) {
      const disabledNext = Array.from(document.querySelectorAll('a,button,[role="button"],input[type="button"],input[type="submit"]'))
        .some(el => !isInsideOwnOverlay(el) && isVisible(el) && looksLikeNext(el) && !isEnabled(el));
      if (disabledNext) {
        result.active = true;
        result.seconds = null;
        result.text = 'LMS wait/unlock in progress';
        lmsWaitSignature = getPageTimerSignature();
        lmsWaitLastSeenAt = Date.now();
        return result;
      }
    }

    return result;
  }

  function hasDisabledLmsNextControl() {
    try {
      return Array.from(document.querySelectorAll('a,button,[role="button"],input[type="button"],input[type="submit"]'))
        .some(el => !isInsideOwnOverlay(el) && isVisible(el) && looksLikeNext(el) && !isEnabled(el));
    } catch (error) {
      return false;
    }
  }

  function describeLmsModuleWait(waitInfo, now = Date.now()) {
    const secondsText = waitInfo?.seconds != null ? `${waitInfo.seconds}s` : 'until the LMS unlocks Next';
    if (nextTimerEnabled) {
      const customRemaining = Math.max(0, nextTimerCountdownFromPageClock(now) ?? 0);
      return `Auto detection ON · LMS module wait ${secondsText}; custom timer ${customRemaining}s remaining. Next will click only after both timers are complete.`;
    }
    return `Auto detection ON · LMS module wait ${secondsText}. Next will click when the LMS unlocks it.`;
  }

  function isInsideOwnOverlay(el) {
    return !!(overlay && el && overlay.contains(el));
  }

  function isVisible(el) {
    if (!el || !(el instanceof Element) || isInsideOwnOverlay(el)) return false;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function isEnabled(el) {
    if (!el || !(el instanceof Element)) return false;
    if (el.disabled) return false;
    if (el.getAttribute('aria-disabled') === 'true') return false;
    if (el.classList.contains('disabled')) return false;
    if (el.closest('[aria-disabled="true"], .disabled, [disabled]')) return false;
    return true;
  }

  function isInViewport(el) {
    const r = el.getBoundingClientRect();
    return r.bottom > 0 && r.right > 0 && r.top < (window.innerHeight || document.documentElement.clientHeight) && r.left < (window.innerWidth || document.documentElement.clientWidth);
  }

  function visibleInteractiveElements() {
    const selectors = [
      'a',
      'button',
      'input[type="button"]',
      'input[type="submit"]',
      '[role="button"]',
      '[onclick]',
      '.btn',
      '.Button',
      '[aria-label]'
    ];
    return Array.from(document.querySelectorAll(selectors.join(',')))
      .filter(el => isVisible(el) && isEnabled(el));
  }

  function isRetakeControlText(text) {
    return /\b(take|start|begin|retake|retry|attempt)\s+(the\s+)?(quiz|test|exam|assessment)\s+again\b/.test(text) ||
      /\b(take|start|begin|retake|retry|attempt)\s+(again|another attempt)\b/.test(text) ||
      /\b(quiz|test|exam|assessment)\s+(again|retake|retry)\b/.test(text);
  }

  function hasQuizStartControl(elementTexts, quizWords) {
    return elementTexts.some(text => {
      if (!text || isRetakeControlText(text)) return false;
      if (/\b(take|start|begin|resume|attempt)\s+(the\s+)?(quiz|test|exam|assessment)\b/.test(text)) return true;
      if (/\b(quiz|test|exam|assessment)\s+(start|begin|take|resume|attempt)\b/.test(text)) return true;
      if (/\b(start attempt|attempt quiz|attempt test|attempt exam|take the quiz|take quiz|take exam|start quiz|start exam|begin quiz|begin exam)\b/.test(text)) return true;
      return quizWords && /^(start|begin|resume|attempt)$/i.test(text);
    });
  }

  function hasStrongActiveQuizSignals(body, path, elementTexts, quizWords) {
    // v2.1.8: AOL Canvas take URL is the highest-priority quiz signal.
    // Active attempts on AOL consistently use /quizzes/<id>/take.
    const aolQuizTakePriority = /\/quizzes\/[^/]+\/take(?:\b|\/)/.test(path);
    if (aolQuizTakePriority) return true;

    const visibleAnswerControls = Array.from(document.querySelectorAll(
      'input[type="radio"], input[type="checkbox"], textarea, select'
    )).some(el => isVisible(el) && isEnabled(el));

    const visibleQuizSubmit = elementTexts.some(text =>
      /\b(submit quiz|submit test|submit exam|submit assessment|finish attempt|submit attempt)\b/.test(text)
    );

    // Canvas/AOL quiz pages expose these while an attempt is actively running.
    const canvasTakePath = /\/quizzes\/[^/]+\/take(?:\b|\/)/.test(path);
    const canvasQuizForm = !!document.querySelector('form#submit_quiz_form, form[action*="/quizzes/"][action*="submissions"]');
    const canvasQuestions = !!document.querySelector('#questions .question, .quiz-submission .question, .question_holder .question');
    const runningTimer = /\btime\s+running\b/.test(body);
    const questionNavigation = /\bquestion\s+\d+\b/.test(body) && /\bquestions\b/.test(body);

    // Strong active-attempt signals take priority over generic result/grade text elsewhere
    // in the page shell. This prevents a 4-5 second delay or a false "completed" state.
    if (visibleQuizSubmit && (visibleAnswerControls || canvasQuestions || runningTimer || canvasTakePath)) return true;
    if (canvasTakePath && (visibleAnswerControls || canvasQuestions || canvasQuizForm)) return true;
    if (canvasQuizForm && (visibleAnswerControls || canvasQuestions)) return true;
    if (quizWords && runningTimer && (visibleAnswerControls || canvasQuestions || questionNavigation)) return true;

    // v2.1.7 AOL graded quiz fallback detection:
    // Some quiz attempts do not expose Canvas question IDs.
    const genericQuizAttempt = (
      /\bquestion\s+\d+\b/.test(body) &&
      /\b\d+\s*(?:pts?|points?)\b/.test(body) &&
      /\b(submit\s+quiz|quiz\s+saved|time\s+running)\b/.test(body)
    );
    if (genericQuizAttempt) return true;

    return false;
  }


  function formatClock(totalSeconds) {
    const seconds = Math.max(0, Math.floor(Number(totalSeconds) || 0));
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const sec = seconds % 60;
    if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
    return `${m}:${String(sec).padStart(2, '0')}`;
  }

  function isStrongActivityTitleSelector(selector = '', documentTitle = false) {
    if (documentTitle) return true;
    return /quiz_title|quiz-title|ic-quiz-header__title|page-title|data-testid.*quiz/i.test(String(selector || ''));
  }

  function scoreActivityTitleCandidate(value, selector = '', documentTitle = false) {
    const raw = String(value || '').replace(/\s+/g, ' ').trim();
    const title = normalizeExamTitle(raw);
    if (!title || title.length > 180) return -1000;

    if (/^(submission details|attempt history|submission history|questions|course details|quiz results|exam results)$/i.test(title)) return -500;
    if (/^question\s+\d+$/i.test(title)) return -500;

    const strongSelector = isStrongActivityTitleSelector(selector, documentTitle);
    const primaryHeading = /(^|\s|>)h1(?:$|\s|\[|\.)/i.test(String(selector || ''));
    let score = 0;

    // A section heading that merely says "Final Exam" inside a syllabus must never
    // outrank the real page title. Exact assessment words receive strong weight only
    // when they come from an LMS activity-title surface, document title, or primary H1.
    if (isFinalExamName(title)) score += strongSelector ? 1000 : (primaryHeading ? 650 : 180);
    if (isPracticalExamName(title)) score += strongSelector ? 980 : (primaryHeading ? 630 : 175);
    if (/^online exam$/i.test(title)) score += strongSelector ? 1000 : (primaryHeading ? 650 : 180);
    if (/^module\s+\d+\s+quiz$/i.test(title)) score += strongSelector ? 900 : (primaryHeading ? 620 : 170);
    if (/^quiz\s*\d+$/i.test(title)) score += strongSelector ? 760 : (primaryHeading ? 560 : 150);
    if (/^(quiz|test|assessment|module quiz)$/i.test(title)) score += strongSelector ? 620 : (primaryHeading ? 470 : 120);
    if (/quiz_title|quiz-title|ic-quiz-header__title/i.test(selector)) score += 260;
    if (/page-title/i.test(selector)) score += 120;
    if (documentTitle) score += 80;
    if (title.length <= 80) score += 30;
    return score;
  }

  function getLikelyActivityTitle() {
    const selectors = [
      '#quiz_title',
      '.quiz-title',
      '.ic-Quiz-header__title',
      '.page-title',
      '[data-testid*="quiz"] h1',
      '[data-testid*="quiz"] h2',
      'main h1',
      'main h2',
      '#content h1',
      '#content h2',
      'header h1',
      'h1',
      'h2'
    ];
    const candidates = [];
    for (const selector of selectors) {
      for (const el of document.querySelectorAll(selector)) {
        if (!isVisible(el)) continue;
        const text = String(el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
        if (!text) continue;
        candidates.push({ text, score: scoreActivityTitleCandidate(text, selector, false) });
      }
    }
    const documentTitle = String(document.title || '').split(/\s*[|•]\s*/)[0].trim();
    if (documentTitle) candidates.push({ text: documentTitle, score: scoreActivityTitleCandidate(documentTitle, 'document.title', true) });

    candidates.sort((a, b) => b.score - a.score || a.text.length - b.text.length);
    const best = candidates.find(candidate => candidate.score >= 300);
    if (best) return best.text;

    // Weak H2 assessment words are accepted only when the page itself exposes real LMS
    // assessment evidence. This lets result/start pages work while syllabus section names
    // remain ordinary read-only course content.
    const body = getBodyText();
    const path = normalizeText(location.pathname + ' ' + location.hash);
    const elementText = visibleInteractiveElements().map(getElementText).join(' | ');
    const hasAssessmentEvidence = hasStructuredAssessmentMetadata(body) ||
      hasActualAssessmentResultSignals(body, elementText) || hasAssessmentRoute(path);
    const weakAssessment = hasAssessmentEvidence
      ? candidates.find(candidate => isAssessmentTitleName(candidate.text) && candidate.score > 0)
      : null;

    return weakAssessment?.text || documentTitle || candidates.find(candidate => candidate.score > -500)?.text || 'Course content';
  }

  function parseQuestionNumber(value) {
    const text = normalizeText(value);
    let match = text.match(/\bquestion\s*#?\s*(\d+)\b/i);
    if (match) return Number(match[1]);
    match = text.match(/^\s*(\d+)\s*[.)-]?\s*$/);
    if (match) return Number(match[1]);
    return null;
  }

  function questionNumberFromElement(el, fallbackIndex) {
    if (!el) return fallbackIndex + 1;
    const explicitNumber = el.getAttribute?.('data-question-number');
    if (/^\d+$/.test(String(explicitNumber || ''))) return Number(explicitNumber);

    const selectors = [
      '.question_name',
      '.question-name',
      '.question-title',
      '.question_header',
      '.header',
      'h2',
      'h3',
      '[aria-label*="Question" i]'
    ];
    for (const selector of selectors) {
      const child = el.matches?.(selector) ? el : el.querySelector?.(selector);
      const num = child ? parseQuestionNumber(getElementText(child)) : null;
      if (Number.isFinite(num)) return num;
    }

    // Canvas question element IDs commonly contain an internal database ID rather
    // than the student-facing question number. Do not use that ID as Q12345.
    const ownNum = parseQuestionNumber(getElementText(el).slice(0, 220));
    if (Number.isFinite(ownNum)) return ownNum;
    return fallbackIndex + 1;
  }

  function isPlaceholderSelect(select) {
    if (!select) return true;
    const option = select.options?.[select.selectedIndex];
    const value = String(select.value ?? '').trim();
    const text = normalizeText(option?.textContent || option?.label || '');
    return !value || /^(select|choose|pick|please select|--|none)$/i.test(text);
  }

  function cleanAnswerText(value) {
    return String(value ?? '')
      .replace(/[\u200B-\u200D\uFEFF]/g, '')
      .replace(/\u00a0/g, ' ')
      .trim();
  }

  function isFlagLikeControl(el) {
    const signature = normalizeText([
      el?.name,
      el?.id,
      el?.className,
      el?.getAttribute?.('aria-label'),
      el?.getAttribute?.('title')
    ].filter(Boolean).join(' '));
    return /(?:^|[_\s-])(flag|flagged|marked)(?:$|[_\s-])/.test(signature) ||
      /question_\d+_marked/.test(signature) ||
      /mark\s+(?:this\s+)?question/.test(signature);
  }

  function isRenderedTextAnswerControl(el) {
    if (!el || !(el instanceof Element) || !isEnabled(el)) return false;
    if (el.getAttribute('aria-hidden') === 'true' || el.closest('[aria-hidden="true"]')) return false;
    if (el.readOnly) return false;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function richTextAnswerEvidence(questionEl) {
    const editors = Array.from(questionEl.querySelectorAll(
      '[contenteditable="true"], [role="textbox"][contenteditable], .ql-editor, .ProseMirror, .mce-content-body, .ck-editor__editable'
    ));
    for (const editor of editors) {
      if (!isRenderedTextAnswerControl(editor)) continue;
      const text = cleanAnswerText(editor.innerText || editor.textContent || '');
      const placeholder = cleanAnswerText(
        editor.getAttribute?.('data-placeholder') ||
        editor.getAttribute?.('aria-placeholder') ||
        editor.getAttribute?.('placeholder') || ''
      );
      if (text && (!placeholder || normalizeText(text) !== normalizeText(placeholder))) {
        return { answered: true, authoritative: true, source: 'rich-text' };
      }
      // An editor can contain only formatting tags / <br> while still being blank.
      return { answered: false, authoritative: true, source: 'rich-text' };
    }

    const frames = Array.from(questionEl.querySelectorAll('iframe'));
    for (const frame of frames) {
      const frameSignature = normalizeText(`${frame.id || ''} ${frame.name || ''} ${frame.className || ''} ${frame.title || ''}`);
      if (!/(editor|rich|essay|answer|content|rce|tinymce|ckeditor)/.test(frameSignature)) continue;
      try {
        const frameBody = frame.contentDocument?.body;
        if (!frameBody) continue;
        const text = cleanAnswerText(frameBody.innerText || frameBody.textContent || '');
        return { answered: !!text, authoritative: true, source: 'rich-text-frame' };
      } catch (e) {}
    }
    return null;
  }

  function inspectQuestionAnswerState(questionEl) {
    if (!questionEl) {
      return { answered: false, authoritative: false, source: 'none', controlCount: 0 };
    }

    const radios = Array.from(questionEl.querySelectorAll('input[type="radio"]:not([disabled])'))
      .filter(input => !isFlagLikeControl(input));
    if (radios.length) {
      const answered = radios.some(input => input.checked || input.getAttribute('aria-checked') === 'true');
      return { answered, authoritative: true, source: 'radio', controlCount: radios.length };
    }

    const checks = Array.from(questionEl.querySelectorAll('input[type="checkbox"]:not([disabled])'))
      .filter(input => !isFlagLikeControl(input));
    if (checks.length) {
      const answered = checks.some(input => input.checked || input.getAttribute('aria-checked') === 'true');
      return { answered, authoritative: true, source: 'checkbox', controlCount: checks.length };
    }

    const roleRadios = Array.from(questionEl.querySelectorAll('[role="radio"]'))
      .filter(el => isEnabled(el) && !isFlagLikeControl(el));
    if (roleRadios.length) {
      const answered = roleRadios.some(el => el.getAttribute('aria-checked') === 'true' || el.classList.contains('selected'));
      return { answered, authoritative: true, source: 'aria-radio', controlCount: roleRadios.length };
    }

    const roleChecks = Array.from(questionEl.querySelectorAll('[role="checkbox"]'))
      .filter(el => isEnabled(el) && !isFlagLikeControl(el));
    if (roleChecks.length) {
      const answered = roleChecks.some(el => el.getAttribute('aria-checked') === 'true' || el.classList.contains('selected'));
      return { answered, authoritative: true, source: 'aria-checkbox', controlCount: roleChecks.length };
    }

    const selects = Array.from(questionEl.querySelectorAll('select:not([disabled])'))
      .filter(select => isRenderedTextAnswerControl(select));
    if (selects.length) {
      const answered = selects.every(select => !isPlaceholderSelect(select));
      return { answered, authoritative: true, source: 'select', controlCount: selects.length };
    }

    const textInputs = Array.from(questionEl.querySelectorAll(
      'textarea:not([disabled]), input[type="text"]:not([disabled]), input[type="number"]:not([disabled]), input[type="email"]:not([disabled]), input[type="url"]:not([disabled]), input[type="search"]:not([disabled]), input[type="date"]:not([disabled]), input[type="time"]:not([disabled])'
    )).filter(input => !isFlagLikeControl(input) && isRenderedTextAnswerControl(input));
    if (textInputs.length) {
      const answered = textInputs.every(input => cleanAnswerText(input.value).length > 0);
      return { answered, authoritative: true, source: 'text', controlCount: textInputs.length };
    }

    const fileInputs = Array.from(questionEl.querySelectorAll('input[type="file"]:not([disabled])'))
      .filter(input => !isFlagLikeControl(input));
    if (fileInputs.length) {
      const answered = fileInputs.every(input => input.files && input.files.length > 0);
      return { answered, authoritative: true, source: 'file', controlCount: fileInputs.length };
    }

    const richText = richTextAnswerEvidence(questionEl);
    if (richText) return { ...richText, controlCount: 1 };

    // Only trust explicit status flags when the question DOM has no actual answer
    // control to inspect. Generic words such as "saved", "done" or "complete" are
    // deliberately ignored because LMS auto-save state is not proof of an answer.
    const statusValues = [
      questionEl.getAttribute?.('data-status'),
      questionEl.getAttribute?.('data-answer-status'),
      questionEl.getAttribute?.('data-answered'),
      questionEl.getAttribute?.('aria-label')
    ].filter(Boolean).map(normalizeText);
    const statusText = statusValues.join(' ');
    if (/\b(unanswered|not answered|not attempted|unattempted|blank)\b/.test(statusText) || statusValues.includes('false')) {
      return { answered: false, authoritative: true, source: 'explicit-status', controlCount: 0 };
    }
    if (/\b(answered|attempted)\b/.test(statusText) || statusValues.includes('true')) {
      return { answered: true, authoritative: false, source: 'explicit-status', controlCount: 0 };
    }

    return { answered: false, authoritative: false, source: 'unknown', controlCount: 0 };
  }

  function looksLikeQuestionContainer(el) {
    if (!el || !(el instanceof Element) || isInsideOwnOverlay(el)) return false;
    if (el.closest('#question_list, .question_list, .quiz-nav, [aria-label*="question navigation" i]')) return false;
    if (el.matches('a, button, input, label, [role="button"], [role="radio"], [role="checkbox"]')) return false;

    const hasQuestionHeader = !!el.querySelector?.('.question_name, .question-name, .question-title, .question_header, h2, h3, [aria-label*="Question" i]');
    const hasAnswerControl = !!el.querySelector?.(
      'input[type="radio"], input[type="checkbox"], textarea, select, input[type="text"], input[type="number"], input[type="file"], [role="radio"], [role="checkbox"], [contenteditable="true"], iframe'
    );
    const classText = normalizeText(el.className);
    return hasAnswerControl || hasQuestionHeader || /\b(display_question|question)\b/.test(classText);
  }

  function navQuestionAnswered(el) {
    const stateEl = el?.closest?.('li, [role="listitem"], [data-question-id], [data-question-number]') || el;
    const values = [
      el?.className,
      stateEl?.className,
      el?.getAttribute?.('data-status'),
      stateEl?.getAttribute?.('data-status'),
      el?.getAttribute?.('data-answer-status'),
      stateEl?.getAttribute?.('data-answer-status'),
      el?.getAttribute?.('data-answered'),
      stateEl?.getAttribute?.('data-answered'),
      el?.getAttribute?.('aria-label'),
      stateEl?.getAttribute?.('aria-label'),
      el?.getAttribute?.('title'),
      stateEl?.getAttribute?.('title')
    ].filter(Boolean).map(normalizeText);
    const text = values.join(' ');
    const renderedText = normalizeText(stateEl?.innerText || stateEl?.textContent || '');

    // Canvas/AOL Classic Quiz navigation is the LMS' own answer-state indicator.
    // A question-mark icon means the LMS still considers that question unanswered.
    const hasQuestionMarkIcon = !!stateEl?.querySelector?.(
      '.icon-question, .icon-question-mark, [class*="icon-question" i], [class*="question-mark" i], [aria-label*="unanswered" i], [title*="unanswered" i]'
    );
    if (
      hasQuestionMarkIcon ||
      /\b(unanswered|not answered|not attempted|unattempted|blank)\b/.test(text) ||
      /(?:^|\s)\?\s*question\s*\d+\b/.test(renderedText) ||
      values.includes('false')
    ) return false;

    const hasAnsweredClass = !!stateEl?.classList?.contains('answered') || !!el?.classList?.contains('answered');
    const hasCheckIcon = !!stateEl?.querySelector?.(
      '.icon-check, .icon-checkmark, [class*="icon-check" i], [class*="checkmark" i], [aria-label*="answered" i], [title*="answered" i]'
    );
    if (
      hasAnsweredClass ||
      hasCheckIcon ||
      /\b(answered|attempted|response recorded|answer saved)\b/.test(text) ||
      /[✓✔]\s*question\s*\d+\b/.test(renderedText) ||
      values.includes('true')
    ) return true;

    return null;
  }

  function collectQuizQuestions() {
    const primarySelectors = [
      '#questions .display_question',
      '#questions .question',
      '.quiz-submission .display_question',
      '.quiz-submission .question',
      '.question_holder .display_question',
      '.question_holder .question',
      '.display_question[id^="question_"]',
      '.question[id^="question_"]',
      '[data-question-number]'
    ];

    // Re-scan the live quiz from top to bottom on every 250 ms snapshot. No answer
    // count is cached as truth; current LMS navigation + current controls are re-read.
    const rawQuestions = Array.from(document.querySelectorAll(primarySelectors.join(',')))
      .filter(looksLikeQuestionContainer)
      .sort((a, b) => {
        if (a === b) return 0;
        const pos = a.compareDocumentPosition(b);
        if (pos & Node.DOCUMENT_POSITION_FOLLOWING) return -1;
        if (pos & Node.DOCUMENT_POSITION_PRECEDING) return 1;
        return 0;
      });

    const domMap = new Map();
    const seenElements = new Set();
    rawQuestions.forEach((el, index) => {
      if (!el || seenElements.has(el)) return;
      seenElements.add(el);
      const number = questionNumberFromElement(el, index);
      if (!Number.isFinite(number) || number < 1 || number > 500) return;

      const evidence = inspectQuestionAnswerState(el);
      const candidate = {
        number,
        answered: evidence.answered === true,
        reliable: evidence.authoritative === true,
        source: `question:${evidence.source}`,
        controlCount: evidence.controlCount || 0
      };
      const existing = domMap.get(number);
      if (
        !existing ||
        (candidate.reliable && !existing.reliable) ||
        (candidate.reliable === existing.reliable && candidate.controlCount > (existing.controlCount || 0))
      ) domMap.set(number, candidate);
    });

    const navSelectors = [
      '#question_list a',
      '.question_list a',
      '.quiz-nav a',
      '.quiz_navigation a',
      '[aria-label*="question navigation" i] a',
      '[data-question-number][role="button"]'
    ];
    const navMap = new Map();
    const navElements = Array.from(document.querySelectorAll(navSelectors.join(',')))
      .filter(el => !isInsideOwnOverlay(el));

    navElements.forEach(el => {
      let number = parseQuestionNumber(getElementText(el));
      if (!Number.isFinite(number)) {
        const attr = el.getAttribute?.('data-question-number');
        if (/^\d+$/.test(String(attr || ''))) number = Number(attr);
      }
      if (!Number.isFinite(number) || number < 1 || number > 500) return;

      const navState = navQuestionAnswered(el);
      const existing = navMap.get(number);
      const candidate = {
        number,
        answered: navState === true,
        reliable: navState !== null,
        source: navState === null ? 'navigation:unknown' : 'navigation:lms-state'
      };
      if (!existing || (!existing.reliable && candidate.reliable)) navMap.set(number, candidate);
    });

    const body = getBodyText();
    let expectedTotal = null;
    const ofMatches = Array.from(body.matchAll(/\bquestion\s+\d+\s+(?:of|\/)\s+(\d+)\b/gi));
    if (ofMatches.length) {
      const totals = ofMatches.map(match => Number(match[1])).filter(value => Number.isFinite(value) && value > 0 && value <= 500);
      if (totals.length) expectedTotal = Math.max(...totals);
    }
    const totalMatch = body.match(/\b(?:total\s+questions|questions\s+total|number\s+of\s+questions)\s*:?\s*(\d+)\b/i);
    if (!expectedTotal && totalMatch) expectedTotal = Number(totalMatch[1]);

    const navNumbers = Array.from(navMap.keys()).sort((a, b) => a - b);
    const domNumbers = Array.from(domMap.keys()).sort((a, b) => a - b);
    const isOneToN = numbers => {
      if (numbers.length < 1) return false;
      const distinct = Array.from(new Set(numbers)).sort((a, b) => a - b);
      const max = distinct[distinct.length - 1];
      return distinct[0] === 1 && distinct.length === max && distinct.every((number, index) => number === index + 1);
    };

    if (!expectedTotal && navNumbers.length > 1 && isOneToN(navNumbers)) expectedTotal = Math.max(...navNumbers);
    if (!expectedTotal && domNumbers.length > 1 && isOneToN(domNumbers)) expectedTotal = Math.max(...domNumbers);

    const allNumbers = new Set([...domMap.keys(), ...navMap.keys()]);
    if (Number.isFinite(expectedTotal) && expectedTotal > 0 && expectedTotal <= 500) {
      for (let number = 1; number <= expectedTotal; number += 1) allNumbers.add(number);
    }

    const questions = Array.from(allNumbers)
      .filter(number => !expectedTotal || number <= expectedTotal)
      .sort((a, b) => a - b)
      .map(number => {
        const nav = navMap.get(number);
        const dom = domMap.get(number);

        // IMPORTANT: when the LMS navigation exposes an explicit ? / check state,
        // that live LMS state wins. This prevents prefilled/default/stale radio values
        // from being counted as attempted before Canvas/AOL marks the question answered.
        if (nav?.reliable) {
          return { number, answered: nav.answered, reliable: true, source: nav.source };
        }
        if (dom?.reliable) {
          return { number, answered: dom.answered, reliable: true, source: dom.source };
        }
        return { number, answered: false, reliable: false, source: nav?.source || dom?.source || 'unknown' };
      });

    const questionCountReliable = Number.isFinite(expectedTotal) && expectedTotal > 0 && questions.length === expectedTotal;
    const answerStateReliable = questionCountReliable && questions.every(question => question.reliable === true);

    return {
      questions,
      questionCountReliable,
      answerStateReliable,
      scanSource: navNumbers.length
        ? 'LMS question navigation + top-to-bottom live DOM'
        : 'top-to-bottom live question DOM'
    };
  }

  function parseDurationFromText(text) {
    const normalized = normalizeText(text);
    const minutePatterns = [
      /\b(?:time\s*limit|quiz\s*time|test\s*time|exam\s*time|duration|allowed\s*time)\s*[:\-]?\s*(30|60|120|180)\s*(?:minutes?|mins?)\b/i,
      /\b(30|60|120|180)\s*(?:minutes?|mins?)\s*(?:time\s*limit|limit|duration|allowed)\b/i,
      /\btime_limit["']?\s*[:=]\s*["']?(30|60|120|180)\b/i,
      /\btimeLimit["']?\s*[:=]\s*["']?(30|60|120|180)\b/i
    ];
    for (const pattern of minutePatterns) {
      const match = normalized.match(pattern);
      if (match) {
        const minutes = Number(match[1]);
        if (SUPPORTED_QUIZ_DURATIONS_MIN.has(minutes)) return minutes;
      }
    }

    const hourPatterns = [
      /\b(?:time\s*limit|quiz\s*time|test\s*time|exam\s*time|duration|allowed\s*time)\s*[:\-]?\s*(?:0\.5|1|2|3)\s*(?:hours?|hrs?)\b/i,
      /\b(?:0\.5|1|2|3)\s*(?:hours?|hrs?)\s*(?:time\s*limit|limit|duration|allowed)\b/i
    ];
    for (const pattern of hourPatterns) {
      const match = normalized.match(pattern);
      if (match) {
        const rawHours = match[0].match(/(?:0\.5|1|2|3)/)?.[0];
        const minutes = rawHours != null ? Math.round(Number(rawHours) * 60) : null;
        if (minutes != null && SUPPORTED_QUIZ_DURATIONS_MIN.has(minutes)) return minutes;
      }
    }
    return null;
  }

  function detectQuizDurationMinutesFromDocument(rootDoc, body, sourcePrefix = '') {
    if (!rootDoc) return { minutes: null, source: '' };
    const prefix = sourcePrefix ? `${sourcePrefix} · ` : '';
    const attributeSelectors = [
      '[data-time-limit]',
      '[data-quiz-time-limit]',
      '[data-duration-minutes]',
      'input[name*="time_limit" i]',
      'input[id*="time_limit" i]'
    ];
    for (const el of rootDoc.querySelectorAll(attributeSelectors.join(','))) {
      const values = [
        el.getAttribute?.('data-time-limit'),
        el.getAttribute?.('data-quiz-time-limit'),
        el.getAttribute?.('data-duration-minutes'),
        el.value,
        el.getAttribute?.('value')
      ];
      for (const value of values) {
        const minutes = Number.parseInt(String(value || ''), 10);
        if (SUPPORTED_QUIZ_DURATIONS_MIN.has(minutes)) return { minutes, source: `${prefix}page data` };
      }
    }

    const durationSelectors = [
      '#quiz_time_limit',
      '.quiz_time_limit',
      '.time_limit',
      '[class*="time-limit" i]',
      '[id*="time_limit" i]',
      '[data-testid*="time-limit" i]'
    ];
    for (const el of rootDoc.querySelectorAll(durationSelectors.join(','))) {
      const minutes = parseDurationFromText(String(el.innerText || el.textContent || ''));
      if (minutes) return { minutes, source: `${prefix}quiz time label` };
    }

    const bodyMinutes = parseDurationFromText(body);
    if (bodyMinutes) return { minutes: bodyMinutes, source: `${prefix}page text` };

    for (const script of Array.from(rootDoc.scripts || [])) {
      const text = String(script.textContent || '');
      if (!text || text.length > 2000000) continue;
      const minutes = parseDurationFromText(text);
      if (minutes) return { minutes, source: `${prefix}quiz page data` };
    }

    return { minutes: null, source: '' };
  }

  function detectQuizDurationMinutes(body) {
    return detectQuizDurationMinutesFromDocument(document, body);
  }

  function readActivityMetadataCache() {
    try {
      const raw = window.sessionStorage.getItem(SESSION_ACTIVITY_METADATA_KEY);
      const parsed = raw ? JSON.parse(raw) : [];
      return Array.isArray(parsed) ? parsed.filter(item => item && typeof item === 'object') : [];
    } catch (e) {
      return [];
    }
  }

  function writeActivityMetadataCache(items) {
    try {
      window.sessionStorage.setItem(SESSION_ACTIVITY_METADATA_KEY, JSON.stringify(items.slice(-12)));
    } catch (e) {}
  }

  function saveActivityDurationMetadata(title, activityType, duration, url = location.href) {
    const minutes = Number(duration?.minutes);
    if (!SUPPORTED_QUIZ_DURATIONS_MIN.has(minutes)) return;
    const normalizedTitle = normalizeExamTitle(title);
    if (!normalizedTitle) return;
    const now = Date.now();
    const key = `${location.origin}|${activityType}|${normalizedTitle}`;
    const items = readActivityMetadataCache()
      .filter(item => now - Number(item.capturedAt || 0) <= ACTIVITY_METADATA_MAX_AGE_MS)
      .filter(item => item.key !== key);
    items.push({
      key,
      title: String(title || ''),
      normalizedTitle,
      activityType,
      durationMin: minutes,
      source: String(duration.source || 'LMS activity metadata'),
      url: String(url || ''),
      capturedAt: now
    });
    writeActivityMetadataCache(items);
  }

  function findCachedActivityDuration(title, activityType) {
    const normalizedTitle = normalizeExamTitle(title);
    const now = Date.now();
    const items = readActivityMetadataCache()
      .filter(item => now - Number(item.capturedAt || 0) <= ACTIVITY_METADATA_MAX_AGE_MS)
      .filter(item => item.activityType === activityType && SUPPORTED_QUIZ_DURATIONS_MIN.has(Number(item.durationMin)))
      .sort((a, b) => Number(b.capturedAt || 0) - Number(a.capturedAt || 0));
    const exact = items.find(item => item.normalizedTitle === normalizedTitle);
    if (!exact) return { minutes: null, source: '' };
    return { minutes: Number(exact.durationMin), source: `cached start-page LMS metadata · ${exact.source}` };
  }

  function getLikelyActivityTitleFromDocument(rootDoc) {
    if (!rootDoc) return '';
    const selectors = [
      '#quiz_title', '.quiz-title', '.ic-Quiz-header__title', '.page-title',
      '[data-testid*="quiz"] h1', '[data-testid*="quiz"] h2',
      'main h1', 'main h2', '#content h1', '#content h2', 'header h1', 'h1', 'h2'
    ];
    const candidates = [];
    for (const selector of selectors) {
      for (const el of rootDoc.querySelectorAll(selector)) {
        const text = String(el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
        if (!text) continue;
        candidates.push({ text, score: scoreActivityTitleCandidate(text, selector, false) });
      }
    }
    const documentTitle = String(rootDoc.title || '').split(/\s*[|•]\s*/)[0].trim();
    if (documentTitle) candidates.push({ text: documentTitle, score: scoreActivityTitleCandidate(documentTitle, 'document.title', true) });
    candidates.sort((a, b) => b.score - a.score || a.text.length - b.text.length);
    const best = candidates.find(candidate => candidate.score >= 300);
    if (best) return best.text;

    const body = normalizeText(rootDoc.body?.innerText || rootDoc.body?.textContent || '');
    const hasAssessmentEvidence = hasStructuredAssessmentMetadata(body) || hasActualAssessmentResultSignals(body, '');
    const weakAssessment = hasAssessmentEvidence
      ? candidates.find(candidate => isAssessmentTitleName(candidate.text) && candidate.score > 0)
      : null;
    return weakAssessment?.text || documentTitle || candidates.find(candidate => candidate.score > -500)?.text || '';
  }

  function captureCurrentActivityMetadata() {
    const root = document.body || document.documentElement;
    if (!root) return;
    const body = getBodyText();
    const path = normalizeText(location.pathname + ' ' + location.hash);
    const elementTexts = visibleInteractiveElements().map(getElementText);
    const context = detectAssessmentPageContext(body, path, elementTexts);
    if (!context.realAssessment || context.kind === 'practical-exam') return;
    const activityType = context.kind === 'final-exam' ? 'final-exam' : 'quiz';
    const duration = detectQuizDurationMinutes(body);
    if (duration.minutes) saveActivityDurationMetadata(context.title, activityType, duration);
  }

  function scheduleActivityMetadataCapture(delay = 0) {
    if (activityMetadataCaptureTimer) clearTimeout(activityMetadataCaptureTimer);
    activityMetadataCaptureTimer = setTimeout(() => {
      activityMetadataCaptureTimer = null;
      safeInvoke('activity metadata capture', captureCurrentActivityMetadata);
    }, Math.max(0, Number(delay) || 0));
  }

  function requestReferrerDurationLookup(title, activityType) {
    let referrerUrl;
    try {
      if (!document.referrer) return;
      referrerUrl = new URL(document.referrer, location.href);
      if (referrerUrl.origin !== location.origin || referrerUrl.href === location.href) return;
    } catch (e) {
      return;
    }

    const key = `${referrerUrl.href}|${activityType}|${normalizeExamTitle(title)}`;
    if (referrerDurationLookup.key === key && (referrerDurationLookup.inFlight || referrerDurationLookup.done)) return;
    referrerDurationLookup = { key, inFlight: true, done: false };

    fetch(referrerUrl.href, { credentials: 'include', cache: 'no-store', redirect: 'follow' })
      .then(response => response.ok ? response.text() : Promise.reject(new Error(`HTTP ${response.status}`)))
      .then(html => {
        const doc = new DOMParser().parseFromString(html, 'text/html');
        const previousTitle = getLikelyActivityTitleFromDocument(doc);
        const previousType = isFinalExamName(previousTitle) ? 'final-exam' : 'quiz';
        const sameActivity = normalizeExamTitle(previousTitle) === normalizeExamTitle(title) && previousType === activityType;
        if (!sameActivity) return;
        const body = normalizeText(doc.body?.innerText || doc.body?.textContent || '');
        const duration = detectQuizDurationMinutesFromDocument(doc, body, 'previous start page');
        if (duration.minutes) saveActivityDurationMetadata(title, activityType, duration, referrerUrl.href);
      })
      .catch(() => {})
      .finally(() => {
        referrerDurationLookup = { key, inFlight: false, done: true };
        if (enabled && !manualPaused && !pageSuspended) scheduleLoop(0);
      });
  }

  function parseDurationTokensSeconds(value) {
    const source = String(value || '')
      .replace(/\u00a0/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    if (!source) return null;

    const clock = source.match(/\b(\d{1,3}):(\d{2})(?::(\d{2}))?\b/);
    if (clock) {
      if (clock[3] != null) {
        return Number(clock[1]) * 3600 + Number(clock[2]) * 60 + Number(clock[3]);
      }
      return Number(clock[1]) * 60 + Number(clock[2]);
    }

    const tokens = Array.from(source.matchAll(/(\d+)\s*(hours?|hrs?|minutes?|mins?|seconds?|secs?)/gi));
    if (!tokens.length) return null;

    let hours = 0;
    let minutes = 0;
    let seconds = 0;
    for (const token of tokens) {
      const amount = Number(token[1] || 0);
      const unit = String(token[2] || '').toLowerCase();
      if (unit.startsWith('hour') || unit.startsWith('hr')) hours += amount;
      else if (unit.startsWith('minute') || unit.startsWith('min')) minutes += amount;
      else if (unit.startsWith('second') || unit.startsWith('sec')) seconds += amount;
    }
    return hours * 3600 + minutes * 60 + seconds;
  }

  function parseLabeledTimeSeconds(value, labelPattern) {
    const source = String(value || '')
      .replace(/\u00a0/g, ' ')
      .replace(/\s+/g, ' ');
    const match = source.match(labelPattern);
    if (!match) return null;

    const startAt = (match.index || 0) + match[0].length;
    const tail = source.slice(startAt, startAt + 260);
    return parseDurationTokensSeconds(tail);
  }

  function pushUniqueTimerText(texts, seen, value) {
    const normalized = String(value || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
    if (!normalized || seen.has(normalized)) return;
    seen.add(normalized);
    texts.push(normalized);
  }

  function collectTimerTextsByLabel(labelRegex) {
    const texts = [];
    const seen = new Set();
    const root = document.body || document.documentElement;
    if (!root) return texts;

    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        if (!node?.nodeValue || !labelRegex.test(node.nodeValue)) return NodeFilter.FILTER_REJECT;
        const parent = node.parentElement;
        if (!parent || isInsideOwnOverlay(parent)) return NodeFilter.FILTER_REJECT;
        if (parent.closest('script, style, template, noscript')) return NodeFilter.FILTER_REJECT;
        if (!isVisible(parent) && !(parent.parentElement && isVisible(parent.parentElement))) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });

    let node;
    while ((node = walker.nextNode())) {
      const el = node.parentElement;
      if (!el) continue;
      pushUniqueTimerText(texts, seen, el.innerText || el.textContent);
      pushUniqueTimerText(texts, seen, el.parentElement?.innerText || el.parentElement?.textContent);
      pushUniqueTimerText(texts, seen, el.parentElement?.parentElement?.innerText || el.parentElement?.parentElement?.textContent);

      let sibling = el.nextElementSibling;
      for (let i = 0; sibling && i < 6; i += 1, sibling = sibling.nextElementSibling) {
        pushUniqueTimerText(texts, seen, sibling.innerText || sibling.textContent);
      }
      sibling = el.parentElement?.nextElementSibling;
      for (let i = 0; sibling && i < 4; i += 1, sibling = sibling.nextElementSibling) {
        pushUniqueTimerText(texts, seen, sibling.innerText || sibling.textContent);
      }
    }
    return texts;
  }

  function collectLikelyTimerTexts(kind) {
    const selectors = kind === 'elapsed'
      ? [
          '#time_running',
          '#time_elapsed',
          '.time_running',
          '.time-running',
          '.time_elapsed',
          '.time-elapsed',
          '[id*="time_running" i]',
          '[id*="time_elapsed" i]',
          '[class*="time_running" i]',
          '[class*="time_elapsed" i]',
          '[data-testid*="time-running" i]',
          '[data-testid*="time-elapsed" i]',
          '[aria-label*="time running" i]',
          '[aria-label*="elapsed time" i]',
          '[title*="time running" i]'
        ]
      : [
          '#time_remaining',
          '#time_left',
          '.time_remaining',
          '.time-remaining',
          '.time_left',
          '.time-left',
          '[id*="time_remaining" i]',
          '[id*="time_left" i]',
          '[class*="time_remaining" i]',
          '[class*="time_left" i]',
          '[data-testid*="time-remaining" i]',
          '[data-testid*="time-left" i]',
          '[aria-label*="time remaining" i]',
          '[aria-label*="time left" i]'
        ];

    const texts = [];
    const seen = new Set();
    for (const el of document.querySelectorAll(selectors.join(','))) {
      if (isInsideOwnOverlay(el)) continue;
      const nearby = [
        el.innerText,
        el.textContent,
        el.getAttribute?.('aria-label'),
        el.getAttribute?.('title'),
        el.parentElement?.innerText,
        el.parentElement?.textContent,
        el.parentElement?.parentElement?.innerText,
        el.parentElement?.parentElement?.textContent,
        el.nextElementSibling?.innerText,
        el.nextElementSibling?.textContent,
        el.previousElementSibling?.innerText,
        el.previousElementSibling?.textContent
      ];
      for (const value of nearby) pushUniqueTimerText(texts, seen, value);
    }

    const labelRegex = kind === 'elapsed'
      ? /\b(?:time\s+running|elapsed\s+time|time\s+elapsed)\b/i
      : /\b(?:time\s+left|remaining\s+time|time\s+remaining)\b/i;
    for (const value of collectTimerTextsByLabel(labelRegex)) pushUniqueTimerText(texts, seen, value);
    return texts;
  }

  function parseExplicitElapsedSeconds(body) {
    const labelPattern = /\b(?:elapsed\s+time|time\s+elapsed)\b\s*:?\s*/i;
    for (const text of collectLikelyTimerTexts('elapsed')) {
      if (/\btime\s+running\b/i.test(text) && !/\b(?:elapsed\s+time|time\s+elapsed)\b/i.test(text)) continue;
      const labeled = parseLabeledTimeSeconds(text, labelPattern);
      if (labeled != null) return labeled;
    }
    return parseLabeledTimeSeconds(body, labelPattern);
  }

  function parseExplicitRemainingSeconds(body) {
    const labelPattern = /\b(?:time\s+left|remaining\s+time|time\s+remaining)\b\s*:?\s*/i;
    for (const text of collectLikelyTimerTexts('remaining')) {
      const labeled = parseLabeledTimeSeconds(text, labelPattern);
      if (labeled != null) return labeled;
      if (/\b(?:time\s+left|remaining\s+time|time\s+remaining)\b/i.test(text)) {
        const direct = parseDurationTokensSeconds(text.replace(labelPattern, ''));
        if (direct != null) return direct;
      }
    }
    return parseLabeledTimeSeconds(body, labelPattern);
  }

  function parseTimeRunningSeconds(body) {
    const labelPattern = /\btime\s+running\b\s*:?\s*/i;
    for (const text of collectLikelyTimerTexts('elapsed')) {
      if (!/\btime\s+running\b/i.test(text)) continue;
      const labeled = parseLabeledTimeSeconds(text, labelPattern);
      if (labeled != null) return labeled;
    }
    return parseLabeledTimeSeconds(body, labelPattern);
  }

  function isCanvasAolQuizAttempt(path = normalizeText(location.pathname + ' ' + location.hash)) {
    return /\/quizzes\/[^/]+\/take(?:\b|\/)/.test(path) ||
      !!document.querySelector('form#submit_quiz_form, form[action*="/quizzes/"][action*="submissions"]') ||
      (!!document.querySelector('#question_list, .question_list') && !!document.querySelector('#time_running, .time_running, .time-running'));
  }

  function detectLiveQuizTimer(body, durationMin, path) {
    const durationSeconds = durationMin ? durationMin * 60 : null;
    const explicitRemaining = parseExplicitRemainingSeconds(body);
    const explicitElapsed = parseExplicitElapsedSeconds(body);
    const timeRunning = parseTimeRunningSeconds(body);

    const validWithinLimit = value => value != null && Number.isFinite(value) && value >= 0 && (!durationSeconds || value <= durationSeconds + 5);

    if (validWithinLimit(explicitRemaining)) {
      return {
        remainingSeconds: explicitRemaining,
        elapsedSeconds: durationSeconds ? Math.max(0, durationSeconds - explicitRemaining) : explicitElapsed,
        authoritative: true,
        source: 'LMS remaining-time timer',
        timerMode: 'explicit-remaining',
        rawTimeRunningSeconds: null
      };
    }

    if (validWithinLimit(explicitElapsed)) {
      return {
        elapsedSeconds: explicitElapsed,
        remainingSeconds: durationSeconds ? Math.max(0, durationSeconds - explicitElapsed) : null,
        authoritative: true,
        source: 'LMS elapsed-time timer',
        timerMode: 'explicit-elapsed',
        rawTimeRunningSeconds: null
      };
    }

    // AOL/Canvas Classic Quizzes expose a visible "Time Running" value beside
    // "Hide Time". In the user's live AOL pages this value is a countdown: a fresh
    // 30-minute quiz shows about 29:xx and a 3-hour exam after 59 minutes shows about
    // 2:01:xx. Treat it provisionally as REMAINING for display, but never arm Submit
    // until two real timer movements confirm whether the raw value is counting DOWN or UP.
    // If another LMS uses the same label for elapsed time, the direction validator in
    // processQuizMonitor automatically flips the interpretation after observed upward ticks.
    if (isCanvasAolQuizAttempt(path) && validWithinLimit(timeRunning) && durationSeconds) {
      return {
        elapsedSeconds: Math.max(0, durationSeconds - timeRunning),
        remainingSeconds: timeRunning,
        authoritative: true,
        source: 'AOL/Canvas Time Running · direction validating',
        timerMode: 'time-running',
        rawTimeRunningSeconds: timeRunning
      };
    }

    return {
      remainingSeconds: null,
      elapsedSeconds: null,
      authoritative: false,
      source: '',
      timerMode: '',
      rawTimeRunningSeconds: null
    };
  }

  function isZeroPointOrUngradedActivity() {
    const body = getBodyText();
    const path = normalizeText(location.pathname + ' ' + location.hash);
    const activityContext = /\b(quiz|quizzes|test|exam|assessment|assignment|module|activity|submit|submission)\b/.test(`${body} ${path}`);
    if (!activityContext) return false;

    const pointSignal = getActivityPointSignal(body);
    if (pointSignal.zero) return true;

    const metadataSelectors = [
      '.points_possible',
      '.points-possible',
      '.assignment_points',
      '.assignment-points',
      '.quiz_points',
      '.quiz-points',
      '[data-testid*="points-possible" i]',
      '[aria-label*="points possible" i]'
    ];
    return Array.from(document.querySelectorAll(metadataSelectors.join(',')))
      .filter(el => !isInsideOwnOverlay(el))
      .some(el => /^(?:0|0\.0+)\s*(?:points?|pts?)?(?:\s+possible)?$/i.test(String(el.innerText || el.textContent || '').trim()));
  }

  function createQuizSnapshot(body, path, elementTexts, quizWords) {
    if (!hasStrongActiveQuizSignals(body, path, elementTexts, quizWords)) return null;
    if (isZeroPointOrUngradedActivity()) return null;

    const questionData = collectQuizQuestions();
    const questions = questionData.questions;
    const title = getLikelyActivityTitle();
    const activityType = classifyAssessmentTitle(title) || 'quiz';
    // Keep the live-attempt identity tied to the LMS route, not to a heading candidate.
    // Canvas/AOL can re-render headings while questions save. Including a changing title
    // in the key reset timer validation over and over and could leave a 30-minute quiz
    // stuck on "timer validation in progress" even after the 55% threshold.
    const key = `${location.origin}${location.pathname}${location.search}|${activityType}`;

    // Every snapshot re-reads current LMS values. Nothing in the panel is treated as
    // the source of truth and no independent extension clock is used.
    let duration = detectQuizDurationMinutes(body);
    if (duration.minutes) {
      saveActivityDurationMetadata(title, activityType, duration);
    } else {
      const cachedDuration = findCachedActivityDuration(title, activityType);
      if (cachedDuration.minutes) duration = cachedDuration;
    }

    // Some LMS pages expose both explicit elapsed and remaining timers but hide the
    // time-limit label. Infer only the four supported limits from those TWO independent
    // LMS values. Never infer a total duration from Time Running alone.
    if (!duration.minutes) {
      const explicitElapsed = parseExplicitElapsedSeconds(body);
      const explicitRemaining = parseExplicitRemainingSeconds(body);
      if (explicitElapsed != null && explicitRemaining != null) {
        const combinedSeconds = explicitElapsed + explicitRemaining;
        const inferredMinutes = Math.round(combinedSeconds / 60);
        const driftSeconds = Math.abs(combinedSeconds - inferredMinutes * 60);
        if (SUPPORTED_QUIZ_DURATIONS_MIN.has(inferredMinutes) && driftSeconds <= 5) {
          duration = { minutes: inferredMinutes, source: 'LMS elapsed + remaining timer' };
          saveActivityDurationMetadata(title, activityType, duration);
        }
      }
    }

    if (!duration.minutes) requestReferrerDurationLookup(title, activityType);

    const timer = detectLiveQuizTimer(body, duration.minutes, path);
    const missedNumbers = questions.filter(question => !question.answered).map(question => question.number);

    return {
      key,
      title,
      activityType,
      questions,
      totalQuestions: questions.length,
      questionCountReliable: questionData.questionCountReliable,
      answerStateReliable: questionData.answerStateReliable,
      questionScanSource: questionData.scanSource,
      answeredCount: questions.length - missedNumbers.length,
      missedNumbers,
      durationMin: duration.minutes,
      durationSource: duration.source,
      elapsedSeconds: timer.elapsedSeconds,
      remainingSeconds: timer.remainingSeconds,
      timerAuthoritative: timer.authoritative,
      timerSource: timer.source,
      timerMode: timer.timerMode || '',
      rawTimeRunningSeconds: timer.rawTimeRunningSeconds ?? null,
      timerDirectionConfirmed: timer.timerMode !== 'time-running',
      timerStable: false
    };
  }

  function playWarningTone(kind = 'warning') {
    // v2.1.4 is audio-free by request. No AudioContext is created, so Chrome
    // cannot raise autoplay errors after sleep/wake, lid down, or reconnect.
    return false;
  }

  function requestStartActivityAlarm(isFinalExam) {
    // Audio removed. Keep function as a safe no-op so arrival detection logic
    // remains unchanged and no duplicate/fallback sound can run.
    return false;
  }

  function updateStartActivityAlarm(startControlFound, isFinalExam) {
    if (!startControlFound) {
      startActivityControlPresent = false;
      return;
    }
    if (startActivityControlPresent) return;

    startActivityControlPresent = true;
    requestStartActivityAlarm(isFinalExam);
  }

  function resetQuizState() {
    quizState = createEmptyQuizState();
    quizDetailsCollapsed = false;
    if (quizPanel) {
      quizPanel.dataset.active = '0';
      quizPanel.style.display = 'none';
      quizPanel.textContent = '';
    }
    scheduleOverlayAutoFit('idle');
  }

  function updateQuizPanel(snapshot, note = '') {
    if (!quizPanel || !snapshot) return;
    const quizPanelWasActive = quizPanel.dataset.active === '1';
    const isFinalExam = snapshot.activityType === 'final-exam';
    const activityLabel = getActivityDisplayName(snapshot.title, snapshot.activityType, true);
    const total = snapshot.totalQuestions;
    const answered = snapshot.answeredCount;
    const remainingQuestions = Math.max(0, total - answered);
    const totalDisplay = snapshot.questionCountReliable ? String(total || '?') : '?';
    const remainingDisplay = snapshot.questionCountReliable ? String(remainingQuestions || 0) : '?';
    const missed = snapshot.missedNumbers.length ? snapshot.missedNumbers.map(n => `Q${n}`).join(', ') : 'None';
    const durationSeconds = snapshot.durationMin ? snapshot.durationMin * 60 : null;
    const durationText = durationSeconds != null ? formatClock(durationSeconds) : 'Not detected';
    const elapsedText = snapshot.elapsedSeconds != null ? formatClock(snapshot.elapsedSeconds) : 'Waiting for LMS timer';
    const remainingTimeText = snapshot.remainingSeconds != null ? formatClock(snapshot.remainingSeconds) : 'Not detected';
    const timerSyncText = snapshot.timerAuthoritative
      ? `${snapshot.timerStable ? 'stable' : 'validating'} · ${snapshot.timerSource || 'LMS timer'}`
      : 'LMS timer not detected';
    const remainingThreshold = durationSeconds != null ? durationSeconds * 45 / 100 : null;
    const thresholdText = remainingThreshold != null
      ? `${formatClock(remainingThreshold)} remaining (45% left / 55% spent)`
      : 'Waiting for supported 30/60/120/180 min limit';

    const lines = [
      `${activityLabel} STARTED · LIVE LMS SYNC`,
      `Questions: ${answered}/${totalDisplay} attempted · ${remainingDisplay} remaining`,
      `Missed: ${missed}`,
      `Elapsed: ${elapsedText}`,
      `Remaining: ${remainingTimeText}`,
      `Total time: ${durationText}`,
      `Timer: ${timerSyncText}`,
      `Auto-submit: ${thresholdText}`,
      `Scan: ${snapshot.questionScanSource || 'live activity DOM'}`
    ];
    if (!snapshot.answerStateReliable) lines.push('Answer-state safety: not fully confirmed by LMS; auto-submit blocked.');
    if (note) lines.push(`Status: ${note}`);
    quizPanel.textContent = lines.join('\n');
    quizPanel.dataset.active = '1';
    if (!quizPanelWasActive) scheduleOverlayAutoFit(quizDetailsCollapsed ? 'quiz-hidden' : 'quiz', true);
    else scheduleOverlayResponsiveLayout();
  }

  function findQuizSubmitButton({ confirmOnly = false } = {}) {
    const controls = visibleInteractiveElements();
    const submitPattern = /\b(submit quiz|submit test|submit exam|submit assessment|finish attempt|submit attempt)\b/;
    const dialog = Array.from(document.querySelectorAll('[role="dialog"], .ui-dialog, .modal, .ReactModal__Content'))
      .find(el => isVisible(el));

    const candidates = controls.filter(el => {
      const text = getElementText(el);
      if (confirmOnly) {
        if (!dialog || !dialog.contains(el)) return false;
        return submitPattern.test(text) || /^(submit|confirm|yes, submit|yes)$/i.test(text);
      }
      if (dialog && dialog.contains(el) && (submitPattern.test(text) || /^(submit|confirm)$/i.test(text))) return true;
      return submitPattern.test(text);
    });

    return candidates
      .map(el => ({ el, score: (dialog && dialog.contains(el) ? 200 : 0) + (submitPattern.test(getElementText(el)) ? 100 : 0) + scoreCandidate(el) }))
      .sort((a, b) => b.score - a.score)[0]?.el || null;
  }

  function attemptQuizAutoSubmit(snapshot) {
    if (!enabled || manualPaused || !snapshot || quizState.autoSubmitInFlight || quizState.autoSubmitAttempted) return false;
    if (snapshot.activityType === 'practical-exam') return false;
    if (!snapshot.durationMin || !SUPPORTED_QUIZ_DURATIONS_MIN.has(snapshot.durationMin)) return false;
    if (!snapshot.timerAuthoritative || !snapshot.timerStable || snapshot.remainingSeconds == null || snapshot.elapsedSeconds == null) return false;
    if (!snapshot.questionCountReliable || !snapshot.answerStateReliable || !snapshot.totalQuestions || snapshot.missedNumbers.length) return false;

    const durationSeconds = snapshot.durationMin * 60;
    const remainingThreshold = durationSeconds * 45 / 100; // 45% remaining
    const elapsedThreshold = durationSeconds * 55 / 100; // 55% spent
    const isFinalExam = snapshot.activityType === 'final-exam';

    // Require BOTH sides of the same normalized LMS clock to agree on the 55%-spent
    // point. On the AOL countdown this means raw Time Running <= 45% remaining; on an
    // elapsed timer it means elapsed >= 55%. The direction must already be confirmed.
    if (snapshot.timerMode === 'time-running' && snapshot.timerDirectionConfirmed !== true) return false;
    if (snapshot.elapsedSeconds + 1 < elapsedThreshold) return false;
    if (snapshot.remainingSeconds - 1 > remainingThreshold) return false;
    if (quizState.timerProgressReads < 1) return false;
    if (isFinalExam && Date.now() - Number(quizState.monitorStartedAt || 0) < FINAL_EXAM_MIN_MONITOR_MS) return false;

    const timerMathDrift = Math.abs((snapshot.elapsedSeconds + snapshot.remainingSeconds) - durationSeconds);
    if (timerMathDrift > 5) return false;

    const submit = findQuizSubmitButton();
    if (!submit) {
      quizState.statusNote = '55% spent and all LMS-confirmed questions are attempted, but Submit is not visible yet.';
      return false;
    }

    const activityName = getActivityDisplayName(snapshot.title, snapshot.activityType);
    quizState.autoSubmitInFlight = true;
    quizState.autoSubmitAttempted = true;
    quizState.autoSubmitAttemptedAt = Date.now();
    quizState.submittedByAuto = true;
    if (isFinalExam) setFinalExamSubmitPending(true);
    quizState.statusNote = `55% LMS time-spent threshold reached + all questions LMS-confirmed. Auto-submitting ${activityName} once.`;
    updateQuizPanel(snapshot, quizState.statusNote);
    playWarningTone('submit');

    try {
      submit.scrollIntoView({ behavior: 'auto', block: 'center', inline: 'center' });
      submit.click();
    } catch (e) {
      quizState.autoSubmitInFlight = false;
      if (isFinalExam) setFinalExamSubmitPending(false);
      quizState.statusNote = 'Auto-submit click failed. It will not repeatedly click.';
      updateQuizPanel(snapshot, quizState.statusNote);
      return false;
    }

    const confirmationDeadline = Date.now() + 5000;
    const finishSubmitConfirmation = () => {
      if (!enabled) return;
      const confirm = findQuizSubmitButton({ confirmOnly: true });
      if (confirm && confirm.isConnected && isVisible(confirm) && isEnabled(confirm)) {
        try {
          confirm.click();
          quizState.statusNote = 'Submit confirmation clicked once.';
        } catch (e) {
          quizState.statusNote = 'Submit confirmation could not be clicked.';
        }
        quizState.autoSubmitInFlight = false;
        if (isFinalExam) {
          quizState.statusNote = `${getActivityDisplayName(snapshot.title, snapshot.activityType)} submit confirmation sent. Waiting for LMS completion; Auto Next will pause immediately after submission.`;
          updateQuizPanel(snapshot, quizState.statusNote);
        }
        if (enabled && !manualPaused) scheduleLoop(150);
        return;
      }

      if (Date.now() < confirmationDeadline) {
        setTimeout(() => safeInvoke('submit confirmation', finishSubmitConfirmation), 250);
        return;
      }

      quizState.autoSubmitInFlight = false;
      if (isFinalExam) {
        quizState.statusNote = `${getActivityDisplayName(snapshot.title, snapshot.activityType)} submit click sent. Waiting for LMS completion/navigation; Auto Next will pause immediately after submission.`;
        updateQuizPanel(snapshot, quizState.statusNote);
      }
      if (enabled && !manualPaused) scheduleLoop(150);
    };
    setTimeout(() => safeInvoke('submit confirmation', finishSubmitConfirmation), 300);
    return true;
  }

  function processQuizMonitor(snapshot, now) {
    if (!snapshot) {
      if (quizState.active) resetQuizState();
      return false;
    }

    if (!quizState.active || quizState.key !== snapshot.key) {
      quizState = createEmptyQuizState();
      quizState.active = true;
      quizState.key = snapshot.key;
      quizState.title = snapshot.title;
      quizState.activityType = snapshot.activityType || 'quiz';
      // New live Quiz / Online Exam / Final Exam attempts open with details hidden by default.
      // The Show button stays available; monitoring, timers, and auto-submit guards keep running.
      quizDetailsCollapsed = true;
      quizState.durationMin = snapshot.durationMin;
      quizState.durationSource = snapshot.durationSource;
      quizState.durationScanAt = now;
      quizState.startedAt = 0;
      quizState.monitorStartedAt = now;
      quizState.lastProgressAt = now;
      quizState.lastProgressElapsedSeconds = snapshot.elapsedSeconds || 0;
      quizState.lastAnsweredCount = snapshot.answeredCount;
      const activityName = getActivityDisplayName(snapshot.title, quizState.activityType);
      quizState.statusNote = snapshot.timerAuthoritative
        ? `${activityName} started. Reading live LMS question states and the live LMS timer.`
        : `${activityName} started. Reading live questions; waiting for a supported LMS timer.`;
    }

    quizState.activityType = snapshot.activityType || quizState.activityType || 'quiz';

    if (snapshot.durationMin) {
      quizState.durationMin = snapshot.durationMin;
      quizState.durationSource = snapshot.durationSource;
    }

    // Determine what the raw AOL/Canvas "Time Running" value means from the
    // timer's ACTUAL movement. AOL currently counts it down on the user's course pages,
    // but the validator deliberately supports either direction so a label change cannot
    // silently invert elapsed/remaining time again.
    if (
      snapshot.timerMode === 'time-running' &&
      snapshot.rawTimeRunningSeconds != null &&
      snapshot.durationMin
    ) {
      const durationSeconds = snapshot.durationMin * 60;
      const raw = snapshot.rawTimeRunningSeconds;
      const previousRaw = quizState.lastTimeRunningRawSeconds;
      const previousRawAt = quizState.lastTimeRunningRawSeenAt;
      const hasPreviousRaw = previousRaw != null && previousRawAt > 0;

      if (hasPreviousRaw && raw !== previousRaw) {
        const wallSeconds = Math.max(0, (now - previousRawAt) / 1000);
        const maximumExpectedMove = Math.max(8, Math.ceil(wallSeconds) + 8);
        const rawDelta = raw - previousRaw;
        const plausibleMove = Math.abs(rawDelta) <= maximumExpectedMove;
        const observedDirection = rawDelta < 0 ? 'remaining' : 'elapsed';

        if (plausibleMove) {
          if (quizState.timeRunningDirectionCandidate === observedDirection) {
            quizState.timeRunningDirectionReads += 1;
          } else {
            quizState.timeRunningDirectionCandidate = observedDirection;
            quizState.timeRunningDirectionReads = 1;
          }

          // Two separate moving ticks in the same direction are required before the
          // Time Running field can authorize auto-submit.
          if (quizState.timeRunningDirectionReads >= 2) {
            quizState.timeRunningDirection = observedDirection;
          }
        } else {
          quizState.timeRunningDirectionCandidate = '';
          quizState.timeRunningDirectionReads = 0;
          quizState.timeRunningDirection = '';
        }
      }

      quizState.lastTimeRunningRawSeconds = raw;
      quizState.lastTimeRunningRawSeenAt = now;

      const effectiveDirection = quizState.timeRunningDirection || 'remaining';
      if (effectiveDirection === 'remaining') {
        snapshot.remainingSeconds = raw;
        snapshot.elapsedSeconds = Math.max(0, durationSeconds - raw);
      } else {
        snapshot.elapsedSeconds = raw;
        snapshot.remainingSeconds = Math.max(0, durationSeconds - raw);
      }

      snapshot.timerDirectionConfirmed = !!quizState.timeRunningDirection;
      snapshot.timerSource = snapshot.timerDirectionConfirmed
        ? `AOL/Canvas Time Running ${effectiveDirection === 'remaining' ? 'countdown' : 'elapsed'} · direction confirmed`
        : 'AOL/Canvas Time Running · validating countdown direction';
    }

    // Validate the normalized live LMS clock on consecutive scans. For Time Running,
    // timerStable cannot become true until the raw direction has been confirmed from
    // real movement. This prevents both early-submit and never-submit inversions.
    if (
      snapshot.timerAuthoritative &&
      snapshot.elapsedSeconds != null &&
      snapshot.remainingSeconds != null
    ) {
      const previousElapsed = quizState.lastLiveElapsedSeconds;
      const previousRemaining = quizState.lastLiveRemainingSeconds;
      const previousAt = quizState.lastLiveTimerSeenAt;
      const hasPrevious = previousElapsed != null && previousRemaining != null && previousAt > 0;
      let validSequence = !hasPrevious;
      let progressed = false;

      if (hasPrevious) {
        const elapsedWallSeconds = Math.max(0, (now - previousAt) / 1000);
        const maximumExpectedMove = Math.ceil(elapsedWallSeconds) + 5;
        const elapsedRise = snapshot.elapsedSeconds - previousElapsed;
        const remainingDrop = previousRemaining - snapshot.remainingSeconds;
        const sidesAgree = Math.abs(elapsedRise - remainingDrop) <= 2;

        validSequence =
          elapsedRise >= -1 && elapsedRise <= maximumExpectedMove &&
          remainingDrop >= -1 && remainingDrop <= maximumExpectedMove &&
          sidesAgree;
        progressed = validSequence && (elapsedRise > 0 || remainingDrop > 0);
      }

      if (!hasPrevious || !validSequence) {
        quizState.timerStableReads = 1;
        quizState.timerProgressReads = 0;
        quizState.firstLiveTimerSeenAt = now;
      } else {
        quizState.timerStableReads += 1;
        if (progressed) quizState.timerProgressReads += 1;
      }

      quizState.lastLiveElapsedSeconds = snapshot.elapsedSeconds;
      quizState.lastLiveRemainingSeconds = snapshot.remainingSeconds;
      quizState.lastLiveTimerSeenAt = now;
      quizState.timerSource = snapshot.timerSource;
      const directionReady = snapshot.timerMode !== 'time-running' || snapshot.timerDirectionConfirmed === true;
      snapshot.timerStable = directionReady && quizState.timerStableReads >= 2 && quizState.timerProgressReads >= 1;
    } else {
      quizState.timerStableReads = 0;
      quizState.timerProgressReads = 0;
      quizState.firstLiveTimerSeenAt = 0;
      quizState.lastLiveElapsedSeconds = null;
      quizState.lastLiveRemainingSeconds = null;
      quizState.lastLiveTimerSeenAt = 0;
      quizState.timeRunningDirection = '';
      quizState.timeRunningDirectionCandidate = '';
      quizState.timeRunningDirectionReads = 0;
      quizState.lastTimeRunningRawSeconds = null;
      quizState.lastTimeRunningRawSeenAt = 0;
      snapshot.timerStable = false;
    }

    quizState.totalQuestions = snapshot.totalQuestions;
    quizState.questionCountReliable = snapshot.questionCountReliable;
    quizState.answerStateReliable = snapshot.answerStateReliable;
    quizState.answeredCount = snapshot.answeredCount;
    quizState.missedNumbers = snapshot.missedNumbers.slice();
    quizState.elapsedSeconds = snapshot.elapsedSeconds;
    quizState.remainingSeconds = snapshot.remainingSeconds;

    if (snapshot.answeredCount > quizState.lastAnsweredCount) {
      quizState.lastProgressAt = now;
      quizState.lastProgressElapsedSeconds = snapshot.elapsedSeconds;
      quizState.lastAnsweredCount = snapshot.answeredCount;
      quizState.statusNote = `Live LMS progress: ${snapshot.answeredCount}/${snapshot.totalQuestions} attempted.`;
    } else if (snapshot.answeredCount < quizState.lastAnsweredCount) {
      quizState.lastAnsweredCount = snapshot.answeredCount;
      quizState.lastProgressAt = now;
      quizState.statusNote = 'Live LMS state shows an answer was cleared or is no longer confirmed.';
    }

    const durationSeconds = snapshot.durationMin ? snapshot.durationMin * 60 : null;
    if (durationSeconds && snapshot.timerAuthoritative && snapshot.elapsedSeconds != null && snapshot.remainingSeconds != null) {
      const noStartThreshold = durationSeconds * QUIZ_NO_START_WARNING_PERCENT;
      if (!quizState.noStartWarningSent && snapshot.elapsedSeconds >= noStartThreshold && snapshot.answeredCount === 0) {
        quizState.noStartWarningSent = true;
        quizState.statusNote = 'WARNING: 20% of quiz time has passed and the LMS still shows 0 questions attempted.';
        playWarningTone('warning');
      }

      const stallSeconds = Math.min(8 * 60, Math.max(3 * 60, durationSeconds * 0.05));
      const stalledForMs = now - quizState.lastProgressAt;
      const canRepeat = now - quizState.lastStallWarningAt >= Math.max(QUIZ_WARNING_REPEAT_MS, stallSeconds * 1000);
      if (snapshot.answeredCount > 0 && snapshot.missedNumbers.length > 0 && stalledForMs >= stallSeconds * 1000 && canRepeat) {
        quizState.lastStallWarningAt = now;
        quizState.statusNote = `WARNING: this timed activity is still running and the LMS has not confirmed a new attempted question for ${Math.round(stallSeconds / 60)} min. Please continue.`;
        playWarningTone('warning');
      }

      const remainingThreshold = durationSeconds * (1 - QUIZ_AUTO_SUBMIT_PERCENT);
      const elapsedThreshold = durationSeconds * QUIZ_AUTO_SUBMIT_PERCENT;
      const secondsUntilThreshold = Math.max(0, Math.ceil(snapshot.remainingSeconds - remainingThreshold));
      const atSubmitThreshold =
        snapshot.elapsedSeconds + 1 >= elapsedThreshold &&
        snapshot.remainingSeconds - 1 <= remainingThreshold;

      // Recompute from the CURRENT normalized LMS clock every scan. On AOL/Canvas the
      // Time Running field is normally a countdown, so 4:37 on a 30-minute quiz means
      // 25:23 spent and the 55% threshold has already passed.
      if (atSubmitThreshold && !snapshot.timerStable) {
        quizState.statusNote = snapshot.timerMode === 'time-running' && snapshot.timerDirectionConfirmed !== true
          ? '55% time-spent threshold appears reached, but AOL/Canvas Time Running direction is still being verified from live ticks. Auto-submit remains blocked for safety.'
          : '55% LMS time-spent threshold reached, but live timer validation is still in progress. Auto-submit is blocked until the LMS clock ticks consistently.';
      } else if (atSubmitThreshold && !snapshot.questionCountReliable) {
        quizState.statusNote = '55% LMS time-spent threshold reached, but total question count is not confirmed. Auto-submit is blocked.';
      } else if (atSubmitThreshold && !snapshot.answerStateReliable) {
        quizState.statusNote = '55% LMS time-spent threshold reached, but one or more answer states are not confirmed by LMS/live controls. Auto-submit is blocked.';
      } else if (atSubmitThreshold && snapshot.missedNumbers.length > 0) {
        quizState.statusNote = `55% LMS time-spent threshold reached, but auto-submit is blocked. Missing: ${snapshot.missedNumbers.map(n => `Q${n}`).join(', ')}.`;
      } else if (!atSubmitThreshold && snapshot.questionCountReliable && snapshot.answerStateReliable && snapshot.missedNumbers.length === 0) {
        quizState.statusNote = `All questions are LMS-confirmed attempted. Waiting ${formatClock(secondsUntilThreshold)} until the LMS reaches 45% remaining / 55% spent.`;
      } else if (!atSubmitThreshold && /^45% time remaining reached|^55% LMS (?:elapsed-time|time-spent) threshold reached/.test(quizState.statusNote || '')) {
        quizState.statusNote = `Live LMS timer synced. 55% submit threshold has not been reached yet; ${formatClock(secondsUntilThreshold)} until 45% remaining.`;
      }
    } else if (durationSeconds && !snapshot.timerAuthoritative) {
      quizState.statusNote = 'Waiting for the live LMS quiz timer. Auto-submit is blocked until the real timer is detected.';
    } else if (!durationSeconds) {
      quizState.statusNote = 'Waiting for a confirmed 30/60/120/180 minute LMS time limit from the current, cached, or exact-matching previous start page. Auto-submit is blocked.';
    }

    // Evaluate submit eligibility before the final panel paint for this scan. The submit
    // routine may replace the status note with "Auto-submitting..."; painting afterwards
    // prevents an older pre-threshold note from visually winning a same-tick DOM race.
    attemptQuizAutoSubmit(snapshot);
    updateQuizPanel(snapshot, quizState.statusNote);
    return true;
  }

  function normalizeExamTitle(value) {
    return normalizeText(value)
      .replace(/[()\[\]{}]/g, ' ')
      .replace(/[–—:_-]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function isOnlineExamName(value) {
    const title = normalizeExamTitle(value);
    return /^online exam$/.test(title);
  }

  function isPracticalExamName(value) {
    const title = normalizeExamTitle(value);
    return /^(?:final exam practical(?: component)?|practical exam(?: component)?|final practical exam)$/.test(title);
  }

  function isFinalExamName(value) {
    const title = normalizeExamTitle(value);
    return /^final exam$/.test(title) || isOnlineExamName(title);
  }

  function isQuizTitleName(value) {
    const title = normalizeExamTitle(value);
    return /^(?:module\s+\d+\s+quiz|module quiz|quiz(?:\s+\d+)?|test(?:\s+\d+)?|assessment(?:\s+\d+)?)$/.test(title);
  }

  function isAssessmentTitleName(value) {
    return isFinalExamName(value) || isPracticalExamName(value) || isQuizTitleName(value);
  }

  function classifyAssessmentTitle(value) {
    if (isPracticalExamName(value)) return 'practical-exam';
    if (isFinalExamName(value)) return 'final-exam';
    if (isQuizTitleName(value)) return 'quiz';
    return '';
  }

  function getActivityDisplayName(title, activityType, uppercase = false) {
    let name = 'Quiz';
    if (activityType === 'practical-exam' || isPracticalExamName(title)) name = 'Practical Exam';
    else if (activityType === 'final-exam') name = isOnlineExamName(title) ? 'Online Exam' : 'Final Exam';
    return uppercase ? name.toUpperCase() : name;
  }

  function hasAssessmentRoute(path) {
    const value = normalizeText(path || '');
    return /(?:^|\/)(?:quizzes?|tests?|exams?|assessments?)(?:\/|$)/.test(value) ||
      /\/courses\/[^/]+\/quizzes\/[^/]+/.test(value);
  }

  function hasStructuredAssessmentMetadata(body) {
    const text = normalizeText(body);
    const signals = [
      /\btime\s*limit\s*:?[\s-]*(?:30|60|120|180)\s*(?:minutes?|mins?)\b/.test(text) ||
        /\btime\s*limit\s*:?[\s-]*(?:0\.5|1|2|3)\s*(?:hours?|hrs?)\b/.test(text),
      /\bpoints\s*:?[\s-]*\d+\b/.test(text) || /\b\d+(?:\.\d+)?\s*(?:points?|pts?)\s+possible\b/.test(text),
      /\bquestions\s*:?[\s-]*\d+\b/.test(text),
      /\ballowed\s+attempts\s*:?[\s-]*\d+\b/.test(text),
      /\battempt\s+history\b/.test(text),
      /\b(?:take|start|begin|launch)\s+(?:the\s+)?quiz\b/.test(text),
      /\b(?:take|start|begin|launch)\s+(?:the\s+)?exam\b/.test(text),
      /\battempt\s+(?:quiz|exam)\b/.test(text)
    ];
    return signals.filter(Boolean).length >= 2 || (signals[0] && (signals[1] || signals[2] || signals[3]));
  }

  function getActivityPointSignal(body, elementText = '') {
    const text = normalizeText(`${body || ''} ${elementText || ''}`);
    const zero = /\b(?:0\s+points?\s+possible|0\s+pts?\s+possible|points?\s+possible\s*:?\s*0(?:\.0+)?\b|pts?\s+possible\s*:?\s*0(?:\.0+)?\b|points?\s*:?\s*0(?:\.0+)?\b|out\s+of\s+0\s+(?:points?|pts?)|worth\s+0(?:\.0+)?\s+(?:points?|pts?)|grading\s*:?\s*(?:none|not\s+graded|ungraded)|not\s+graded|ungraded\s+assignment|no\s+grading)\b/.test(text);

    // Positive grading evidence must come from LMS point metadata or question point
    // labels, not from generic course prose. This is deliberately broad enough for
    // Canvas/AOL: "Points 40", "5 Points Possible", and "Question 1 1 pts".
    const positive = !zero && (
      /\bpoints?\s*:?\s*(?:[1-9]\d*)(?:\.\d+)?\b/.test(text) ||
      /\b(?:[1-9]\d*)(?:\.\d+)?\s*(?:points?|pts?)\s+possible\b/.test(text) ||
      /\bquestion\s+\d+[^\n|]{0,80}\b(?:[1-9]\d*)(?:\.\d+)?\s*(?:points?|pts?)\b/.test(text) ||
      /\b(?:[1-9]\d*)(?:\.\d+)?\s*(?:points?|pts?)\b/.test(text)
    );

    return { zero, positive };
  }

  function isPositiveGradedActivity(body = getBodyText(), elementText = '') {
    const signal = getActivityPointSignal(body, elementText);
    return signal.positive && !signal.zero;
  }

  function hasActualAssessmentResultSignals(body, elementText = '') {
    const text = `${normalizeText(body)} ${normalizeText(elementText)}`;
    const scoreValue = /\b(?:quiz score|exam score|test score|current score|kept score|score for this quiz|score for this exam|score)\s*:?[\s-]*\d+(?:\.\d+)?\s*(?:out of|\/)\s*\d+(?:\.\d+)?\b/.test(text);
    const attemptTime = /\bthis attempt took\s+\d+\s*(?:seconds?|minutes?|hours?)\b/.test(text);
    const submittedStamp = /\bsubmitted\s+(?:[a-z]{3,9}\s+\d{1,2}|\d{1,2}[\/-]\d{1,2}|at\s+\d{1,2}:\d{2})\b/.test(text);
    const resultShell = /\b(attempt history|submission details|submission history|attempt details|view results|view submission)\b/.test(text);
    return (resultShell && (scoreValue || attemptTime || submittedStamp)) || scoreValue || attemptTime;
  }

  function isReadOnlyCourseContentPage(body, path, assessmentContext = null) {
    const text = normalizeText(body);
    const context = assessmentContext || { realAssessment: false };
    if (context.realAssessment) return false;
    const title = normalizeExamTitle(String(document.title || '').split(/\s*[|•]\s*/)[0]);
    const contentSignals = /\b(course overview|purpose of the course|course delivery|welcome module|course components|course component summary|learner support|syllabus|you may now proceed)\b/.test(text) ||
      /\bsyllabus\b/.test(title) || /\/pages\//.test(normalizeText(path || ''));
    const noLiveAnswers = !document.querySelector('input[type="radio"], input[type="checkbox"], textarea, select, form#submit_quiz_form, .quiz-submission .question, #questions .question');
    return contentSignals && noLiveAnswers;
  }

  function detectAssessmentPageContext(body, path, elementTexts) {
    const texts = Array.isArray(elementTexts) ? elementTexts : [];
    const elementText = texts.join(' | ');
    const quizWords = /\b(quiz|quizzes|test|exam|assessment|question|questions)\b/.test(body) || /\b(quizzes|quiz|tests|test|exam|assessment)\b/.test(path);
    const title = getLikelyActivityTitle();
    const titleKind = classifyAssessmentTitle(title);
    const pointSignal = getActivityPointSignal(body, elementText);
    const activeAttempt = hasStrongActiveQuizSignals(body, path, texts, quizWords);
    const startControlFound = hasQuizStartControl(texts, quizWords);
    const routeEvidence = hasAssessmentRoute(path);
    const metadataEvidence = hasStructuredAssessmentMetadata(body);
    const resultEvidence = hasActualAssessmentResultSignals(body, elementText);
    const rawRealAssessment = activeAttempt || startControlFound || resultEvidence ||
      (!!titleKind && (routeEvidence || metadataEvidence));
    // A visible 0 Points Possible / ungraded signal always wins. Those AOL items are
    // treated like normal course content and Auto Next should continue to Next.
    const realAssessment = rawRealAssessment && !pointSignal.zero;
    const kind = titleKind || (activeAttempt || startControlFound ? 'quiz' : '');
    const completed = realAssessment && hasCompletedQuizSignals(body, elementText, path, { title, kind, activeAttempt, startControlFound, routeEvidence, metadataEvidence, resultEvidence });
    return {
      title,
      kind,
      realAssessment,
      activeAttempt,
      startControlFound,
      routeEvidence,
      metadataEvidence,
      resultEvidence,
      positivePoints: pointSignal.positive,
      zeroPoints: pointSignal.zero,
      completed,
      quizWords
    };
  }

  function isFinalExamPage() {
    const body = getBodyText();
    const path = normalizeText(location.pathname + ' ' + location.hash);
    const elementTexts = visibleInteractiveElements().map(getElementText);
    const context = detectAssessmentPageContext(body, path, elementTexts);
    return context.realAssessment && context.kind === 'final-exam';
  }

  function hasCompletedQuizSignals(body, elementText, path, context = null) {
    const text = `${normalizeText(body)} ${normalizeText(elementText)} ${normalizeText(path)}`;
    const pendingFinalSubmit = getFinalExamSubmitPending();
    const assessmentEvidence = pendingFinalSubmit || context?.activeAttempt || context?.startControlFound || context?.resultEvidence || context?.metadataEvidence || context?.routeEvidence ||
      hasActualAssessmentResultSignals(body, elementText) || hasStructuredAssessmentMetadata(body) || hasAssessmentRoute(path);
    if (!assessmentEvidence) return false;

    const hasRetakeButton = isRetakeControlText(normalizeText(elementText));
    const hasSubmittedText = /\b(submission submitted|attempt submitted|submitted successfully|successfully submitted|submitted on|submitted at)\b/.test(text) ||
      /\b(quiz|test|exam|assessment|attempt)\s+(completed|complete|submitted|graded|passed)\b/.test(text) ||
      /\b(completed|complete|submitted|graded|passed)\s+(quiz|test|exam|assessment|attempt)\b/.test(text);
    const hasScoreResult = hasActualAssessmentResultSignals(body, elementText);
    const hasAllQuestionsMarked = /\b(all\s+questions\s+(are\s+)?marked|all\s+questions\s+have\s+been\s+marked|questions\s+marked|all\s+answers\s+saved)\b/.test(text);
    const pendingFinalSubmitCompleted = pendingFinalSubmit && /\bsubmitted\b/.test(text);
    return hasRetakeButton || hasSubmittedText || hasScoreResult || hasAllQuestionsMarked || pendingFinalSubmitCompleted;
  }

  function findBlockingReason() {
    const body = getBodyText();
    const path = normalizeText(location.pathname + ' ' + location.hash);
    const elements = visibleInteractiveElements();
    const elementTexts = elements.map(getElementText);
    const elementText = elementTexts.join(' | ');
    const combined = `${body} ${elementText} ${path}`;
    const assessmentContext = detectAssessmentPageContext(body, path, elementTexts);
    const protectedAssessment = isProtectedAssessmentContext(assessmentContext);

    const zeroPointOrUngraded = isZeroPointOrUngradedActivity() || assessmentContext.zeroPoints;
    if (zeroPointOrUngraded) {
      updateStartActivityAlarm(false, false);
      return '';
    }

    if (protectedAssessment) scheduleActivityMetadataCapture(0);

    // Arrival alert only for a positively identified real LMS assessment start control.
    updateStartActivityAlarm(
      protectedAssessment && assessmentContext.startControlFound && !assessmentContext.activeAttempt,
      assessmentContext.kind === 'final-exam' || assessmentContext.kind === 'practical-exam'
    );

    const hardPrerequisiteBlock = /\b(completion prerequisites|hasn['’]?t been unlocked yet|has not been unlocked yet|not been unlocked yet|will be unlocked|before this page will be unlocked|requirements need to be completed before|following requirements need to be completed|required before this page|must score at least|must score|must complete|required module|prerequisite module|locked until|module prerequisite|completion requirement)\b/.test(body);
    if (hardPrerequisiteBlock && !findNextButton()) {
      return 'Paused: this page is locked by completion prerequisites and no usable Next control is available yet. Auto-detection will resume when Next becomes available.';
    }

    // Explicit read-only course/syllabus content wins over incidental words such as
    // "Module Quiz", "Final Exam", "graded assessments", or "40 questions" in prose.
    // These pages contain no live assessment UI and should flow straight to course Next.
    if (isReadOnlyCourseContentPage(body, path, assessmentContext)) {
      return '';
    }

    if (protectedAssessment && assessmentContext.activeAttempt) {
      if (assessmentContext.kind === 'practical-exam') {
        return 'Paused: active Practical Exam detected. Complete the practical assessment manually; Auto Next will wait for the real course Next control.';
      }
      return assessmentContext.kind === 'final-exam'
        ? `Paused: active ${getActivityDisplayName(assessmentContext.title, 'final-exam')} detected. Final-assessment monitor is tracking live LMS time, progress, and missed questions.`
        : 'Paused: active quiz/test detected. Quiz monitor is tracking manual progress and missed questions.';
    }

    if (protectedAssessment && assessmentContext.startControlFound) {
      if (assessmentContext.kind === 'practical-exam') {
        return 'Paused: Practical Exam start button found. Start and complete it manually; Auto Next will remain paused on the real assessment.';
      }
      return assessmentContext.kind === 'final-exam'
        ? `Paused: ${getActivityDisplayName(assessmentContext.title, 'final-exam')} start button found. Start it manually; live monitoring begins as soon as the attempt opens.`
        : 'Paused: quiz/test start button found. Start it manually; monitoring begins as soon as the quiz attempt opens.';
    }

    if (protectedAssessment && assessmentContext.quizWords && !assessmentContext.completed) {
      const hasAnswerControls = !!document.querySelector('input[type="radio"], input[type="checkbox"], textarea, select');
      const hasQuizSubmit = /\b(submit quiz|submit test|submit exam|submit assessment|finish attempt|submit attempt|next question|question \d+)\b/.test(combined);
      if (hasAnswerControls || hasQuizSubmit) {
        return 'Paused: real quiz/test page detected. Complete it manually; auto-detection will resume after completion.';
      }
    }

    // Assignments, practice pages, upload pages and read-only lessons are not protected
    // assessments. They may contain "Submit Assignment" or completion words, but the
    // user's rule is: keep going unless this is a real graded quiz / online exam / final
    // exam / practical exam. Therefore these words do not pause Auto Next when a course
    // Next control is available.
    if (!protectedAssessment && /\b(mark as done|mark done|submit assignment|upload assignment|start assignment|begin assignment|submit file|submit online)\b/.test(elementText)) {
      return '';
    }

    if (!protectedAssessment && !assessmentContext.completed && /\b(must complete|required to complete|complete this module|complete the module|complete all required|module requirement|requirements not met|locked until|prerequisite|required item|item is required|not been completed|needs to be completed|must view|must submit|must score)\b/.test(body)) {
      if (findNextButton() || getNextHrefFromDocument() || isCourseContentRoute(path)) return '';
      return 'Paused: required-completion warning found and no usable Next control is available yet.';
    }

    return '';
  }

  function safeHrefInfo(el) {
    const hrefAttr = el.getAttribute?.('href');
    if (!hrefAttr) return { hasHref: false, href: '', unsafe: false };

    const trimmed = hrefAttr.trim();
    if (!trimmed || trimmed === '#' || /^javascript:/i.test(trimmed)) {
      return { hasHref: true, href: trimmed, unsafe: true };
    }

    let url;
    try {
      url = new URL(trimmed, location.href);
    } catch (e) {
      return { hasHref: true, href: trimmed, unsafe: false };
    }

    const current = new URL(location.href);
    current.hash = '';
    const target = new URL(url.href);
    target.hash = '';

    return {
      hasHref: true,
      href: url.href,
      unsafe: target.href === current.href
    };
  }

  function looksLikeNext(el) {
    const text = getElementText(el);
    const rel = normalizeText(el.getAttribute?.('rel'));
    const aria = normalizeText(el.getAttribute?.('aria-label'));
    const href = normalizeText(el.getAttribute?.('href'));
    const id = normalizeText(el.id);
    const className = normalizeText(el.className);
    const all = `${text} ${aria} ${rel} ${href} ${id} ${className}`;

    if (!text && !aria && !rel && !href && !id && !className) return false;

    if (/\b(previous|prev|back|cancel|close|submit|finish|done|mark as done|start quiz|start exam|take quiz|take exam|take quiz again|take exam again|retake quiz|retake exam|resume quiz|start attempt|submit quiz|next question)\b/.test(all)) return false;
    if (/\bnext\s+(question|answer|attempt|quiz|test|exam)\b/.test(all)) return false;
    if (/\b(take|start|begin|retake|retry|attempt)\s+(the\s+)?(quiz|test|exam|assessment)\s+again\b/.test(all)) return false;

    if (rel === 'next') return true;
    if (/\bnext[-_\s]*(link|button|btn|module|item|page|activity)\b/.test(`${id} ${className}`)) return true;
    if (/\bnext\s+(module|item|page|activity|lesson)\b/.test(`${text} ${aria}`)) return true;
    if (/\b(module|item|page|activity|lesson)\s+next\b/.test(`${text} ${aria}`)) return true;
    if (/^(next|continue|proceed|›|»|→|next >)$/i.test(text)) return true;
    if (/\b(next|continue|proceed)\b/.test(text) && !/\bquestion\b/.test(text)) return true;

    return false;
  }

  function scoreCandidate(el) {
    const text = getElementText(el);
    const id = normalizeText(el.id);
    const className = normalizeText(el.className);
    const rel = normalizeText(el.getAttribute?.('rel'));
    const aria = normalizeText(el.getAttribute?.('aria-label'));
    const href = normalizeText(el.getAttribute?.('href'));
    const rect = el.getBoundingClientRect();
    let score = 0;

    if (rel === 'next') score += 220;
    if (/\b(next-link|next_link|next-button|next_button|next-btn|next_btn)\b/.test(`${id} ${className}`)) score += 180;
    if (/\bmodule-sequence|sequence-footer|module_item|module-item|item-sequence\b/.test(`${id} ${className} ${href}`)) score += 150;
    if (/\bnext\s+(module|item|page|activity|lesson)\b/.test(`${text} ${aria}`)) score += 140;
    if (/^next$/i.test(text)) score += 120;
    if (/\bnext\b/i.test(text)) score += 90;
    if (/\bcontinue|proceed\b/i.test(text)) score += 55;
    if (el.matches('a[href]')) score += 40;
    if (el.matches('button, [role="button"], input[type="button"], input[type="submit"]')) score += 25;
    if (isInViewport(el)) score += 10;

    // LMS navigation is commonly lower/right on the page.
    score += Math.max(0, rect.top / Math.max(1, window.innerHeight)) * 8;
    score += Math.max(0, rect.left / Math.max(1, window.innerWidth)) * 4;

    const hrefInfo = safeHrefInfo(el);
    if (hrefInfo.hasHref && hrefInfo.unsafe) score -= 250;

    return score;
  }

  function findNextButton() {
    const candidates = visibleInteractiveElements()
      .filter(looksLikeNext)
      .map(el => ({ el, score: scoreCandidate(el) }))
      .filter(item => item.score > 0)
      .sort((a, b) => b.score - a.score);
    if (candidates[0]?.el) return candidates[0].el;

    // Canvas/AOL sometimes renders the module footer in a way that does not look
    // like a normal visible button during script scans. Fall back to a semantic
    // Next search so read-only content pages do not get stuck.
    return findHardNextControl();
  }

  function looksLikeForceNext(el) {
    const text = getElementText(el);
    const rel = normalizeText(el.getAttribute?.('rel'));
    const aria = normalizeText(el.getAttribute?.('aria-label'));
    const href = normalizeText(el.getAttribute?.('href'));
    const id = normalizeText(el.id);
    const className = normalizeText(el.className);
    const all = `${text} ${aria} ${rel} ${href} ${id} ${className}`;

    if (/\b(previous|prev|back|cancel|close|submit|finish|done|mark as done|start quiz|start exam|take quiz|take exam|retake|resume quiz|start attempt|submit quiz)\b/.test(all)) return false;
    if (/\bnext\s+(question|answer|attempt|quiz|test|exam)\b/.test(all)) return false;

    return rel === 'next' ||
      /\bnext[-_\s]*(link|button|btn|module|item|page|activity|lesson|content)\b/.test(`${id} ${className}`) ||
      /\b(next|continue|proceed)\b/.test(`${text} ${aria}`) ||
      /(?:^|[\/_-])next(?:[\/_-]|$)/.test(href);
  }

  function findForceNextButton() {
    const candidates = visibleInteractiveElements()
      .filter(looksLikeForceNext)
      .map(el => ({ el, score: scoreCandidate(el) + (normalizeText(el.getAttribute?.('rel')) === 'next' ? 300 : 0) }))
      .sort((a, b) => b.score - a.score);
    return candidates[0]?.el || null;
  }

  function elementKey(el) {
    if (!el) return '';
    const hrefInfo = safeHrefInfo(el);
    const r = el.getBoundingClientRect();
    return [
      getElementText(el),
      el.tagName,
      el.id || '',
      String(el.className || ''),
      hrefInfo.href || '',
      Math.round(r.top),
      Math.round(r.left)
    ].join('|');
  }

  function canScrollDown() {
    const y = window.scrollY || document.documentElement.scrollTop || 0;
    return (window.innerHeight + y) < (document.documentElement.scrollHeight - 8);
  }

  function scrollDownStep() {
    const now = Date.now();
    if (now - lastScrollAt < 600) return;
    lastScrollAt = now;
    window.scrollBy({ top: SCROLL_STEP_PX, behavior: 'smooth' });
  }

  function readOverlayGeometry() {
    try {
      const raw = window.sessionStorage.getItem(SESSION_OVERLAY_GEOMETRY_KEY);
      if (!raw) return null;
      const value = JSON.parse(raw);
      if (!value || typeof value !== 'object') return null;
      return value;
    } catch (e) {
      return null;
    }
  }

  function saveOverlayGeometry() {
    if (!overlay || !overlay.isConnected) return;
    try {
      const rect = overlay.getBoundingClientRect();
      const geometry = {
        left: Math.round(rect.left),
        top: Math.round(rect.top),
        width: Math.round(rect.width),
        height: Math.round(rect.height)
      };
      window.sessionStorage.setItem(SESSION_OVERLAY_GEOMETRY_KEY, JSON.stringify(geometry));
    } catch (e) {}
  }

  function clampOverlayToViewport() {
    if (!overlay || !overlay.isConnected) return;
    const rect = overlay.getBoundingClientRect();
    const maxLeft = Math.max(0, window.innerWidth - Math.min(rect.width, window.innerWidth));
    const maxTop = Math.max(0, window.innerHeight - Math.min(rect.height, window.innerHeight));
    const left = Math.min(Math.max(0, rect.left), maxLeft);
    const top = Math.min(Math.max(0, rect.top), maxTop);
    overlay.style.left = `${left}px`;
    overlay.style.top = `${top}px`;
    overlay.style.right = 'auto';
    overlay.style.bottom = 'auto';
  }

  function attachOverlay() {
    if (!overlay || overlay.isConnected) return;
    const parent = document.documentElement || document.body;
    if (parent) parent.appendChild(overlay);
  }

  function updateOverlayControls() {
    if (!overlay) return;
    const pause = overlay.querySelector('#auto-next-detector-pause');
    const resume = overlay.querySelector('#auto-next-detector-resume');
    const force = overlay.querySelector('#auto-next-detector-force-next');
    if (pause) pause.disabled = !enabled || manualPaused;
    if (resume) resume.disabled = !enabled;
    if (force) force.disabled = !enabled;
  }

  function getCompactOverlayMessage() {
    const normalized = normalizeText(message);

    if (manualPaused) return 'Auto detection PAUSED';
    if (shouldShowNextTimerCountdown()) {
      const secondsLeft = nextTimerCountdownSeconds();
      return `Auto detection ON · Next in ${secondsLeft} sec`;
    }
    if (/\bforce next\b/.test(normalized)) {
      if (/\bclicked next once\b/.test(normalized)) return 'Force Next · clicked once';
      if (/\bno usable course next\b/.test(normalized)) return 'Force Next · no Next found';
      if (/\bclick failed\b/.test(normalized)) return 'Force Next · click failed';
      return 'Force Next · one-click mode';
    }
    if (/\bresumed\b/.test(normalized)) return 'Auto detection RESUMED';
    if (/\boffline\b/.test(normalized)) return 'Auto detection PAUSED · offline';
    if (quizState.active) return quizState.activityType === 'final-exam' || quizState.activityType === 'practical-exam'
      ? `Auto detection ON · ${getActivityDisplayName(quizState.title, quizState.activityType)} monitoring`
      : 'Auto detection ON · quiz monitoring';
    if (/\bpaused\b/.test(normalized)) return 'Auto detection PAUSED';
    if (/\bnext button detected\b|\btimer on\b|\bclicking in\b/.test(normalized)) return nextTimerEnabled ? `Auto detection ON · ${nextTimerStatusText()}` : 'Auto detection ON · Next detected';
    if (/\b0-point\b|\bungraded\b/.test(normalized)) return 'Auto detection ON · 0-point activity';
    return 'Auto detection ON';
  }

  function getOverlayAutoContentState() {
    if (quizPanel?.dataset.active === '1' && quizState.active) {
      return quizDetailsCollapsed ? 'quiz-hidden' : 'quiz';
    }
    return 'idle';
  }

  function toggleQuizDetails() {
    if (!quizState.active || quizPanel?.dataset.active !== '1') return;
    quizDetailsCollapsed = !quizDetailsCollapsed;
    scheduleOverlayAutoFit(quizDetailsCollapsed ? 'quiz-hidden' : 'quiz', true);
  }

  function markOverlayManualResize(event) {
    if (!overlay || event.button !== 0) return;
    if (event.target.closest('button')) return;
    const rect = overlay.getBoundingClientRect();
    const nearRight = event.clientX >= rect.right - 22;
    const nearBottom = event.clientY >= rect.bottom - 22;
    if (!nearRight || !nearBottom) return;

    overlayAutoFitState = 'manual';
    overlay.dataset.autoFitState = 'manual';
    scheduleOverlayResponsiveLayout();
  }

  function applyOverlayAutoFit(state, force = false) {
    if (!overlay || !overlay.isConnected) return;
    const targetState = state === 'quiz' ? 'quiz' : state === 'quiz-hidden' ? 'quiz-hidden' : 'idle';
    if (!force && overlayAutoFitState === targetState && overlay.dataset.autoFitState === targetState) {
      scheduleOverlayResponsiveLayout();
      return;
    }

    overlayAutoFitState = targetState;
    overlay.dataset.autoFitState = targetState;

    // Auto-fit only changes presentation geometry. Detection, quiz/final-exam monitoring,
    // timers, navigation and click logic continue unchanged in the background.
    overlay.style.height = 'auto';
    overlay.style.width = targetState === 'quiz'
      ? `${Math.min(430, Math.max(360, window.innerWidth - 24))}px`
      : targetState === 'quiz-hidden'
        ? `${Math.min(220, Math.max(170, window.innerWidth - 24))}px`
        : `${Math.min(330, Math.max(270, window.innerWidth - 24))}px`;

    applyResponsiveOverlayLayout();
    requestAnimationFrame(() => {
      if (!overlay || !overlay.isConnected || overlay.dataset.autoFitState !== targetState) return;
      clampOverlayToViewport();
      saveOverlayGeometry();
    });
  }

  function scheduleOverlayAutoFit(state = null, force = false) {
    if (!overlay) return;
    const targetState = state || getOverlayAutoContentState();
    if (overlayAutoFitRaf) cancelAnimationFrame(overlayAutoFitRaf);
    overlayAutoFitRaf = requestAnimationFrame(() => {
      overlayAutoFitRaf = null;
      applyOverlayAutoFit(targetState, force);
    });
  }

  function renderOverlayMessage() {
    if (!overlay) return;
    const text = overlay.querySelector('#auto-next-detector-text');
    if (!text) return;

    const autoFitState = overlay.dataset.autoFitState || overlayAutoFitState;
    const showCountdown = shouldShowNextTimerCountdown();
    if ((autoFitState === 'idle' || autoFitState === 'quiz-hidden') && !showCountdown) {
      text.style.display = 'none';
      updateOverlayCountdownBadge();
      return;
    }

    text.style.display = '';
    const countdownLine = nextTimerCountdownLine();
    // The live Next timer already appears as a small header badge (for example, "Next in 7s").
    // Keep the body clean so the compact panel does not repeat the countdown text.
    const displayMessage = showCountdown
      ? 'Auto detection ON'
      : (overlayLayoutMode === 'full' ? message : getCompactOverlayMessage());
    if (text.textContent !== displayMessage) text.textContent = displayMessage;
    updateOverlayCountdownBadge();
  }

  function getOverlayLayoutMode(width, height) {
    if (width < 205 || height < 84) return 'minimal';
    if (width < 275 || height < 108) return 'controls';
    if (width < 340 || height < 245) return 'compact';
    return 'full';
  }

  function updateOverlayCountdownBadge() {
    if (!overlay) return;
    const badge = overlay.querySelector('#auto-next-detector-countdown-badge');
    if (!badge) return;
    if (!shouldShowNextTimerCountdown()) {
      badge.style.display = 'none';
      badge.textContent = '';
      return;
    }
    const secondsLeft = nextTimerCountdownSeconds();
    badge.textContent = `Next in ${secondsLeft}s`;
    badge.style.display = '';
  }

  function applyResponsiveOverlayLayout() {
    if (!overlay || !overlay.isConnected) return;
    const rect = overlay.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const autoFitState = overlay.dataset.autoFitState || overlayAutoFitState;
    const mode = autoFitState === 'idle'
      ? 'idle-auto'
      : autoFitState === 'quiz-hidden'
        ? 'quiz-hidden'
        : autoFitState === 'quiz'
          ? 'full'
          : getOverlayLayoutMode(width, height);

    overlayLayoutMode = mode;
    overlay.dataset.layoutMode = mode;

    const dragBar = overlay.querySelector('#auto-next-detector-drag-bar');
    const content = overlay.querySelector('#auto-next-detector-content');
    const dragTitle = overlay.querySelector('#auto-next-detector-drag-title');
    const detailsToggle = overlay.querySelector('#auto-next-detector-details-toggle');
    const countdownBadge = overlay.querySelector('#auto-next-detector-countdown-badge');
    const text = overlay.querySelector('#auto-next-detector-text');
    const row = overlay.querySelector('#auto-next-detector-controls');
    const resume = overlay.querySelector('#auto-next-detector-resume');
    const pause = overlay.querySelector('#auto-next-detector-pause');
    const stop = overlay.querySelector('#auto-next-detector-stop');
    const force = overlay.querySelector('#auto-next-detector-force-next');
    const hint = overlay.querySelector('#auto-next-detector-resize-hint');

    const liveActivity = quizPanel?.dataset.active === '1' && quizState.active;
    const showDetails = mode === 'full' && liveActivity && !quizDetailsCollapsed;
    if (quizPanel) quizPanel.style.display = showDetails ? 'block' : 'none';

    const showCountdown = shouldShowNextTimerCountdown();
    if (text) text.style.display = ((mode === 'idle-auto' || mode === 'quiz-hidden') && !showCountdown) ? 'none' : '';
    if (countdownBadge) {
      countdownBadge.style.display = showCountdown ? '' : 'none';
      countdownBadge.style.fontSize = (mode === 'minimal' || mode === 'idle-auto' || mode === 'quiz-hidden') ? '10px' : '10.5px';
    }
    if (detailsToggle) {
      detailsToggle.style.display = liveActivity ? '' : 'none';
      detailsToggle.textContent = quizDetailsCollapsed ? 'Show' : 'Hide';
      detailsToggle.setAttribute('aria-label', quizDetailsCollapsed ? 'Show live details' : 'Hide live details');
      detailsToggle.title = quizDetailsCollapsed ? 'Show live details' : 'Hide live details';
    }

    // Idle auto-fit deliberately keeps all four controls visible. If the user
    // manually resizes from the bottom-right corner, the previous progressive
    // responsive rules take over again: Force Next, then Resume/Pause hide.
    if (mode === 'quiz-hidden') {
      if (force) force.style.display = 'none';
      if (stop) stop.style.display = 'none';
      if (pause) pause.style.display = manualPaused ? 'none' : '';
      if (resume) resume.style.display = manualPaused ? '' : 'none';
    } else {
      if (force) force.style.display = mode === 'idle-auto'
        ? ''
        : (mode === 'controls' || mode === 'minimal') ? 'none' : '';
      if (resume) resume.style.display = mode === 'minimal' ? 'none' : '';
      if (pause) pause.style.display = mode === 'minimal' ? 'none' : '';
      if (stop) stop.style.display = '';
    }
    if (hint) hint.style.display = mode === 'full' && autoFitState !== 'quiz' && height >= 300 ? 'block' : 'none';

    if (dragBar) {
      if (dragTitle) {
        if (mode === 'idle-auto' || mode === 'quiz-hidden') {
          dragTitle.textContent = `Auto Next v${EXTENSION_VERSION}`;
        } else {
          dragTitle.textContent = mode === 'minimal'
            ? `Auto Next v${EXTENSION_VERSION}`
            : mode === 'full'
              ? `Auto Next v${EXTENSION_VERSION}  ·  drag to move`
              : `Auto Next v${EXTENSION_VERSION} · move`;
        }
      }
      dragBar.style.padding = (mode === 'idle-auto' || mode === 'quiz-hidden')
        ? '5px 8px 4px'
        : mode === 'minimal'
          ? '5px 7px 4px'
          : mode === 'full' ? '8px 10px 6px' : '6px 8px 5px';
      dragBar.style.fontSize = (mode === 'minimal' || mode === 'idle-auto' || mode === 'quiz-hidden') ? '10px' : '11px';
    }

    if (content) {
      content.style.padding = (mode === 'idle-auto' || mode === 'quiz-hidden')
        ? (showCountdown ? '5px 7px 7px' : '5px 7px 7px')
        : mode === 'full'
          ? '9px 10px 10px'
          : mode === 'compact'
            ? '7px 8px 8px'
            : mode === 'controls'
              ? '6px 7px 7px'
              : '4px 6px 5px';
      content.style.minHeight = '0';
      content.style.overflow = mode === 'full' ? 'auto' : 'hidden';
    }

    if (text) {
      text.style.fontSize = mode === 'full' ? '13px' : mode === 'minimal' ? '10.5px' : '11.5px';
      text.style.lineHeight = mode === 'full' ? '1.35' : '1.25';
    }

    if (row) {
      row.style.marginTop = (mode === 'idle-auto' || mode === 'quiz-hidden')
        ? (showCountdown ? '5px' : '0')
        : mode === 'full' ? '9px' : mode === 'minimal' ? '4px' : '6px';
      row.style.gap = mode === 'minimal' ? '4px' : (mode === 'idle-auto' || mode === 'quiz-hidden') ? '5px' : '6px';
      row.style.justifyContent = 'flex-start';
      row.style.overflow = 'hidden';
    }

    for (const button of [resume, pause, stop, force].filter(Boolean)) {
      button.style.padding = mode === 'full' ? '5px 9px' : (mode === 'minimal' || mode === 'quiz-hidden') ? '3px 7px' : '4px 7px';
      button.style.fontSize = mode === 'full' ? '12px' : (mode === 'minimal' || mode === 'quiz-hidden') ? '10px' : '11px';
    }

    renderOverlayMessage();
    updateOverlayControls();
  }

  function scheduleOverlayResponsiveLayout() {
    if (!overlay) return;
    if (overlayResponsiveRaf) cancelAnimationFrame(overlayResponsiveRaf);
    overlayResponsiveRaf = requestAnimationFrame(() => {
      overlayResponsiveRaf = null;
      applyResponsiveOverlayLayout();
    });
  }

  function beginOverlayDrag(event) {
    if (!overlay || event.button !== 0) return;
    if (event.target.closest('button')) return;
    const rect = overlay.getBoundingClientRect();
    overlayDragState = {
      pointerId: event.pointerId,
      offsetX: event.clientX - rect.left,
      offsetY: event.clientY - rect.top
    };
    overlay.style.left = `${rect.left}px`;
    overlay.style.top = `${rect.top}px`;
    overlay.style.right = 'auto';
    overlay.style.bottom = 'auto';
    event.currentTarget.setPointerCapture?.(event.pointerId);
    event.preventDefault();
  }

  function moveOverlayDrag(event) {
    if (!overlay || !overlayDragState || event.pointerId !== overlayDragState.pointerId) return;
    const rect = overlay.getBoundingClientRect();
    const maxLeft = Math.max(0, window.innerWidth - rect.width);
    const maxTop = Math.max(0, window.innerHeight - rect.height);
    const left = Math.min(Math.max(0, event.clientX - overlayDragState.offsetX), maxLeft);
    const top = Math.min(Math.max(0, event.clientY - overlayDragState.offsetY), maxTop);
    overlay.style.left = `${left}px`;
    overlay.style.top = `${top}px`;
    event.preventDefault();
  }

  function endOverlayDrag(event) {
    if (!overlayDragState || event.pointerId !== overlayDragState.pointerId) return;
    overlayDragState = null;
    saveOverlayGeometry();
  }

  function createOverlayButton(id, label, handler) {
    const button = document.createElement('button');
    button.id = id;
    button.textContent = label;
    button.style.cssText = [
      'padding: 5px 9px',
      'cursor: pointer',
      'border: 0',
      'border-radius: 6px',
      'font-size: 12px',
      'line-height: 1.2',
      'white-space: nowrap'
    ].join(';');
    button.addEventListener('click', event => {
      event.preventDefault();
      event.stopPropagation();
      safeInvoke('overlay control', handler);
    });
    return button;
  }

  function createOverlay() {
    if (overlay) {
      attachOverlay();
      return overlay;
    }

    overlay = document.createElement('div');
    overlay.id = 'auto-next-detector-overlay';
    overlay.style.cssText = [
      'position: fixed',
      'right: 14px',
      'bottom: 14px',
      'z-index: 2147483647',
      'background: rgba(20,20,20,0.92)',
      'color: white',
      'font-family: Arial, sans-serif',
      'font-size: 13px',
      'line-height: 1.35',
      'padding: 0',
      'border-radius: 10px',
      'box-shadow: 0 3px 12px rgba(0,0,0,0.35)',
      'width: 420px',
      'height: 280px',
      'min-width: 150px',
      'min-height: 72px',
      'max-width: 92vw',
      'max-height: 82vh',
      'resize: both',
      'overflow: hidden',
      'box-sizing: border-box'
    ].join(';');

    const dragBar = document.createElement('div');
    dragBar.id = 'auto-next-detector-drag-bar';
    dragBar.style.cssText = [
      'padding: 8px 10px 6px',
      'font-weight: 700',
      'font-size: 11px',
      'cursor: move',
      'user-select: none',
      'touch-action: none',
      'border-bottom: 1px solid rgba(255,255,255,0.16)',
      'display:flex',
      'align-items:center',
      'justify-content:space-between',
      'gap:8px'
    ].join(';');

    const dragTitle = document.createElement('span');
    dragTitle.id = 'auto-next-detector-drag-title';
    dragTitle.textContent = `Auto Next v${EXTENSION_VERSION}  ·  drag to move`;
    dragTitle.style.cssText = 'min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;';

    const countdownBadge = document.createElement('span');
    countdownBadge.id = 'auto-next-detector-countdown-badge';
    countdownBadge.textContent = '';
    countdownBadge.style.cssText = [
      'display:none',
      'padding:2px 7px',
      'border:1px solid rgba(255,255,255,0.22)',
      'border-radius:999px',
      'background:rgba(34,197,94,0.22)',
      'color:#f8fafc',
      'font-size:10.5px',
      'font-weight:700',
      'line-height:1.2',
      'white-space:nowrap',
      'flex:0 0 auto'
    ].join(';');

    const detailsToggle = document.createElement('button');
    detailsToggle.id = 'auto-next-detector-details-toggle';
    detailsToggle.type = 'button';
    detailsToggle.textContent = 'Hide';
    detailsToggle.title = 'Hide live details';
    detailsToggle.style.cssText = [
      'display:none',
      'padding:2px 7px',
      'border:1px solid rgba(255,255,255,0.28)',
      'border-radius:5px',
      'background:rgba(255,255,255,0.1)',
      'color:white',
      'font:inherit',
      'font-size:10px',
      'line-height:1.2',
      'cursor:pointer',
      'flex:0 0 auto'
    ].join(';');
    detailsToggle.addEventListener('pointerdown', event => event.stopPropagation());
    detailsToggle.addEventListener('click', event => {
      event.preventDefault();
      event.stopPropagation();
      toggleQuizDetails();
    });
    dragBar.appendChild(dragTitle);
    dragBar.appendChild(countdownBadge);
    dragBar.appendChild(detailsToggle);
    dragBar.addEventListener('pointerdown', beginOverlayDrag);
    dragBar.addEventListener('pointermove', moveOverlayDrag);
    dragBar.addEventListener('pointerup', endOverlayDrag);
    dragBar.addEventListener('pointercancel', endOverlayDrag);

    const content = document.createElement('div');
    content.id = 'auto-next-detector-content';
    content.style.cssText = 'padding: 9px 10px 10px; min-height: 0; box-sizing:border-box; overflow:hidden;';

    const text = document.createElement('div');
    text.id = 'auto-next-detector-text';
    text.textContent = 'Auto Next: starting...';
    text.style.cssText = 'white-space:normal; overflow-wrap:anywhere; word-break:normal; max-width:100%;';

    quizPanel = document.createElement('div');
    quizPanel.id = 'auto-next-detector-quiz-panel';
    quizPanel.dataset.active = '0';
    quizPanel.style.cssText = [
      'display:none',
      'margin-top:8px',
      'padding:8px',
      'border:1px solid rgba(255,255,255,0.22)',
      'border-radius:7px',
      'background:rgba(255,255,255,0.07)',
      'font-size:11px',
      'line-height:1.45',
      'white-space:pre-wrap',
      'overflow-wrap:anywhere'
    ].join(';');

    const row = document.createElement('div');
    row.id = 'auto-next-detector-controls';
    row.style.cssText = 'display:flex; flex-wrap:nowrap; gap:6px; margin-top:9px; align-items:center; overflow:hidden;';

    const resume = createOverlayButton('auto-next-detector-resume', 'Resume', resumeAutoNext);
    const pause = createOverlayButton('auto-next-detector-pause', 'Pause', pauseAutoNext);
    const stop = createOverlayButton('auto-next-detector-stop', 'Stop', () => stopAutoNext('Stopped from page overlay'));
    const forceNext = createOverlayButton('auto-next-detector-force-next', 'Force Next', forceNextOnce);

    const hint = document.createElement('div');
    hint.id = 'auto-next-detector-resize-hint';
    hint.textContent = 'Resize from the bottom-right corner.';
    hint.style.cssText = 'margin-top:7px; font-size:10px; opacity:0.72; user-select:none;';

    row.appendChild(resume);
    row.appendChild(pause);
    row.appendChild(stop);
    row.appendChild(forceNext);
    content.appendChild(text);
    content.appendChild(quizPanel);
    content.appendChild(row);
    content.appendChild(hint);
    overlay.appendChild(dragBar);
    overlay.appendChild(content);
    overlay.addEventListener('pointerdown', markOverlayManualResize, true);
    attachOverlay();

    const saved = readOverlayGeometry();
    if (saved) {
      if (Number.isFinite(saved.width)) overlay.style.width = `${Math.max(150, saved.width)}px`;
      if (Number.isFinite(saved.height)) overlay.style.height = `${Math.max(72, saved.height)}px`;
      if (Number.isFinite(saved.left) && Number.isFinite(saved.top)) {
        overlay.style.left = `${saved.left}px`;
        overlay.style.top = `${saved.top}px`;
        overlay.style.right = 'auto';
        overlay.style.bottom = 'auto';
      }
    }

    if (!overlay.isConnected) {
      document.addEventListener('DOMContentLoaded', attachOverlay, { once: true });
    }

    requestAnimationFrame(() => {
      clampOverlayToViewport();
      scheduleOverlayAutoFit(getOverlayAutoContentState(), true);
    });

    if (typeof ResizeObserver !== 'undefined') {
      overlayResizeObserver = new ResizeObserver(() => {
        safeInvoke('overlay resize', () => {
          clampOverlayToViewport();
          saveOverlayGeometry();
          scheduleOverlayResponsiveLayout();
        });
      });
      overlayResizeObserver.observe(overlay);
    }

    return overlay;
  }

  function updateOverlay(newMessage) {
    message = newMessage || message;
    if (!enabled) return;
    createOverlay();
    renderOverlayMessage();
    updateOverlayControls();
    if (overlayAutoFitState === 'manual') scheduleOverlayResponsiveLayout();
    else scheduleOverlayAutoFit(getOverlayAutoContentState());
  }

  function removeOverlay() {
    if (overlayResizeObserver) {
      overlayResizeObserver.disconnect();
      overlayResizeObserver = null;
    }
    overlayDragState = null;
    if (overlayResponsiveRaf) {
      cancelAnimationFrame(overlayResponsiveRaf);
      overlayResponsiveRaf = null;
    }
    if (overlayAutoFitRaf) {
      cancelAnimationFrame(overlayAutoFitRaf);
      overlayAutoFitRaf = null;
    }
    overlayLayoutMode = 'full';
    overlayAutoFitState = '';
    if (overlay && overlay.parentNode) overlay.parentNode.removeChild(overlay);
    overlay = null;
    quizPanel = null;
  }

  function setSessionEnabled(value) {
    try {
      if (value) window.sessionStorage.setItem(SESSION_ENABLED_KEY, '1');
      else window.sessionStorage.removeItem(SESSION_ENABLED_KEY);
    } catch (e) {}
  }

  function setSessionManualPaused(value) {
    try {
      if (value) window.sessionStorage.setItem(SESSION_MANUAL_PAUSED_KEY, '1');
      else window.sessionStorage.removeItem(SESSION_MANUAL_PAUSED_KEY);
    } catch (e) {}
  }

  function getSessionManualPaused() {
    try {
      return window.sessionStorage.getItem(SESSION_MANUAL_PAUSED_KEY) === '1';
    } catch (e) {
      return false;
    }
  }

  function setFinalExamSubmitPending(value) {
    try {
      if (value) window.sessionStorage.setItem(SESSION_FINAL_EXAM_SUBMIT_PENDING_KEY, '1');
      else window.sessionStorage.removeItem(SESSION_FINAL_EXAM_SUBMIT_PENDING_KEY);
    } catch (e) {}
  }

  function getFinalExamSubmitPending() {
    try {
      return window.sessionStorage.getItem(SESSION_FINAL_EXAM_SUBMIT_PENDING_KEY) === '1';
    } catch (e) {
      return false;
    }
  }

  function clearLoop() {
    if (loopTimer) {
      clearTimeout(loopTimer);
      loopTimer = null;
    }
  }

  function clearClickVerifyTimer() {
    if (clickVerifyTimer) {
      clearTimeout(clickVerifyTimer);
      clickVerifyTimer = null;
    }
  }

  function clearPendingClick() {
    if (clickTimer) {
      clearTimeout(clickTimer);
      clickTimer = null;
    }
    clearClickVerifyTimer();
    pendingNextClick = null;
  }

  function scheduleLoop(ms = CHECK_MS) {
    clearLoop();
    if (enabled && !manualPaused && !pageSuspended) {
      loopTimer = setTimeout(() => mainLoop(false), Math.max(0, Number(ms) || 0));
    }
  }

  function findClickableAncestor(el) {
    if (!el || !(el instanceof Element)) return null;
    if (el.matches('a[href], button, input[type="button"], input[type="submit"], [role="button"], [onclick], .btn, .Button')) return el;
    return el.closest('a[href], button, input[type="button"], input[type="submit"], [role="button"], [onclick], .btn, .Button') || el;
  }

  function validNavigationHref(el) {
    if (!el || !(el instanceof Element)) return '';
    const anchor = el.matches('a[href]') ? el : el.closest('a[href]');
    if (!anchor) return '';
    const hrefInfo = safeHrefInfo(anchor);
    return hrefInfo.hasHref && !hrefInfo.unsafe ? hrefInfo.href : '';
  }

  function isCourseContentRoute(path = location.pathname) {
    const value = normalizeText(path || '');
    return /(?:^|\/)pages(?:\/|$)/.test(value) || /(?:^|\/)modules(?:\/|$)/.test(value) || /(?:^|\/)module_item[s]?(?:\/|$)/.test(value);
  }

  function isProtectedAssessmentContext(context) {
    if (!context || !context.realAssessment || context.zeroPoints) return false;
    if (context.completed) return false;
    // Only real graded quizzes, module quizzes, tests, online/final exams, and practical exams
    // should stop Auto Next. Ordinary pages, assignments, 0-point practice items and syllabus
    // content must keep moving to the next module item.
    return context.kind === 'quiz' || context.kind === 'final-exam' || context.kind === 'practical-exam';
  }

  function getNextHrefFromDocument() {
    const selectors = [
      'a[rel="next"]',
      'link[rel="next"]',
      'a[aria-label*="next" i]',
      'a[title*="next" i]',
      'a.next',
      'a.next_link',
      'a.next-link',
      '.module-sequence-footer a',
      '.module-sequence-footer-button--next',
      '.module_sequence_footer a',
      '.sequence-footer a',
      '.item_sequence_footer a',
      '#module_sequence_footer a',
      '#sequence_footer a',
      'a[href*="module_item"]',
      'a[href*="/modules/"]',
      'a[href*="/pages/"]'
    ];
    const anchors = [];
    for (const selector of selectors) {
      try { anchors.push(...Array.from(document.querySelectorAll(selector))); } catch (e) {}
    }
    const unique = Array.from(new Set(anchors)).filter(el => el instanceof Element && !isInsideOwnOverlay(el));
    const scored = unique.map(el => {
      if (!isEnabled(el)) return null;
      const text = getElementText(el);
      const href = validNavigationHref(el);
      if (!href) return null;
      const all = normalizeText(`${text} ${el.getAttribute?.('aria-label') || ''} ${el.getAttribute?.('title') || ''} ${el.getAttribute?.('rel') || ''} ${el.id || ''} ${el.className || ''}`);
      if (/\b(previous|prev|back|cancel|submit|finish|take quiz|start quiz|start exam|retake|again|next question)\b/.test(all)) return null;
      let score = 0;
      if (normalizeText(el.getAttribute?.('rel')) === 'next') score += 500;
      if (/\bnext\b/.test(all) || /›|»|→/.test(text)) score += 300;
      if (/module[-_\s]*sequence|sequence[-_\s]*footer|module_item|module-item/.test(all + ' ' + href)) score += 170;
      if (isVisible(el)) score += 80;
      if (isInViewport(el)) score += 30;
      const rect = el.getBoundingClientRect?.() || { top: 0, left: 0 };
      score += Math.max(0, rect.top / Math.max(1, window.innerHeight)) * 10;
      score += Math.max(0, rect.left / Math.max(1, window.innerWidth)) * 5;
      return { el, href, score };
    }).filter(Boolean).sort((a, b) => b.score - a.score);
    return scored[0]?.href || '';
  }

  function findHardNextControl() {
    const selectors = [
      'a[rel="next"]',
      'button[aria-label*="next" i]',
      'a[aria-label*="next" i]',
      '[title*="next" i]',
      '.module-sequence-footer a',
      '.module-sequence-footer button',
      '.module-sequence-footer-button--next',
      '.module_sequence_footer a',
      '.module_sequence_footer button',
      '.sequence-footer a',
      '.sequence-footer button',
      '#module_sequence_footer a',
      '#module_sequence_footer button',
      '#sequence_footer a',
      '#sequence_footer button',
      'a[href*="module_item"]',
      'a[href*="/modules/"]',
      'a[href*="/pages/"]',
      'button',
      'a',
      '[role="button"]'
    ];
    const nodes = [];
    for (const selector of selectors) {
      try { nodes.push(...Array.from(document.querySelectorAll(selector))); } catch (e) {}
    }
    const candidates = Array.from(new Set(nodes))
      .filter(el => el instanceof Element && !isInsideOwnOverlay(el) && isEnabled(el))
      .filter(el => isVisible(el) || validNavigationHref(el))
      .filter(el => looksLikeForceNext(el) || looksLikeNext(el) || /\bnext\b|›|»|→/.test(getElementText(el)))
      .map(el => ({ el, score: scoreCandidate(el) + (validNavigationHref(el) ? 120 : 0) + (normalizeText(el.getAttribute?.('rel')) === 'next' ? 500 : 0) }))
      .filter(item => item.score > -100)
      .sort((a, b) => b.score - a.score);
    return candidates[0]?.el || null;
  }

  function dispatchTrustedLikeClick(el) {
    if (!el || !(el instanceof Element)) return;
    const rect = el.getBoundingClientRect();
    const x = Math.max(0, Math.floor(rect.left + Math.min(rect.width / 2, Math.max(1, rect.width - 2))));
    const y = Math.max(0, Math.floor(rect.top + Math.min(rect.height / 2, Math.max(1, rect.height - 2))));
    const opts = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, button: 0, buttons: 1 };
    try { el.focus?.({ preventScroll: true }); } catch (e) {}
    try { if (typeof PointerEvent !== 'undefined') el.dispatchEvent(new PointerEvent('pointerover', { ...opts, pointerId: 1, pointerType: 'mouse', isPrimary: true })); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent('mouseover', opts)); } catch (e) {}
    try { if (typeof PointerEvent !== 'undefined') el.dispatchEvent(new PointerEvent('pointerdown', { ...opts, pointerId: 1, pointerType: 'mouse', isPrimary: true })); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent('mousedown', opts)); } catch (e) {}
    try { if (typeof PointerEvent !== 'undefined') el.dispatchEvent(new PointerEvent('pointerup', { ...opts, pointerId: 1, pointerType: 'mouse', isPrimary: true })); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent('mouseup', opts)); } catch (e) {}
    try { el.dispatchEvent(new MouseEvent('click', opts)); } catch (e) {}
    try { el.click(); } catch (e) {}
  }

  function scheduleClickNavigationVerify(expectedKey, sourceUrl, fallbackHref = '') {
    clearClickVerifyTimer();
    if (!expectedKey) return;
    clickVerifyTimer = setTimeout(() => {
      clickVerifyTimer = null;
      if (!enabled || manualPaused || pageSuspended) return;
      if (location.href !== sourceUrl) return;

      const next = findNextButton();
      if (!next || !next.isConnected || !isVisible(next) || !isEnabled(next)) {
        scheduleLoop(CHECK_MS);
        return;
      }

      const currentKey = elementKey(next);
      const now = Date.now();
      const freshHref = fallbackHref || validNavigationHref(next);
      const retryKey = freshHref || currentKey || expectedKey;
      const canHardRetry = retryKey && (lastHardRetryKey !== retryKey || now - lastHardRetryAt > CLICK_HARD_RETRY_LIMIT_MS);

      if (!canHardRetry) {
        scheduleLoop(CHECK_MS);
        return;
      }

      lastHardRetryKey = retryKey;
      lastHardRetryAt = now;
      lastClickedKey = currentKey;
      lastClickedUrl = location.href;
      lastClickAt = now;

      if (freshHref) {
        updateOverlay('Auto Next: first click did not change the page. Opening the Next link directly now...');
        try {
          window.location.assign(freshHref);
          return;
        } catch (e) {
          // Fall through to one more direct click attempt.
        }
      }

      try {
        const target = findClickableAncestor(next) || next;
        target.scrollIntoView({ behavior: 'auto', block: 'center', inline: 'center' });
        if (target instanceof HTMLAnchorElement) target.setAttribute('target', '_self');
        updateOverlay('Auto Next: first click did not change the page. Retrying the same Next control once...');
        dispatchTrustedLikeClick(target);
      } catch (e) {
        updateOverlay('Auto Next: retry click failed. Detection will keep watching for a valid Next control.');
      }
      scheduleLoop(CHECK_MS);
    }, CLICK_NAVIGATION_VERIFY_MS);
  }

  function clickNext(next) {
    if (!enabled || manualPaused || currentlyClicking || !next || !next.isConnected) return;

    const blockReason = findBlockingReason();
    if (blockReason) {
      updateOverlay(blockReason);
      scheduleLoop(CHECK_MS);
      return;
    }

    const waitInfoBeforeClick = detectLmsModuleWait();
    if (waitInfoBeforeClick.active) {
      updateOverlay(describeLmsModuleWait(waitInfoBeforeClick));
      scheduleLoop(CHECK_MS);
      return;
    }

    if (!isVisible(next) || !isEnabled(next) || !looksLikeNext(next)) {
      scheduleLoop(CHECK_MS);
      return;
    }

    const clickTarget = findClickableAncestor(next) || next;
    const hrefInfo = safeHrefInfo(clickTarget);
    if (hrefInfo.hasHref && hrefInfo.unsafe) {
      updateOverlay('Auto Next: a Next control was found, but its link points to the current page. Waiting for a valid Next button to prevent refresh.');
      scheduleLoop(CHECK_MS);
      return;
    }

    currentlyClicking = true;
    const key = elementKey(next);
    const sourceUrl = location.href;
    const fallbackHref = validNavigationHref(clickTarget) || validNavigationHref(next);
    lastClickedKey = key;
    lastClickedUrl = sourceUrl;
    lastClickAt = Date.now();

    // On ordinary content/module pages, opening the LMS-provided Next href directly is
    // more reliable than synthetic mouse events and does not depend on cookies/history.
    // Protected quiz/exam pages are already blocked before reaching this point.
    if (fallbackHref && !findBlockingReason()) {
      try {
        updateOverlay('Auto Next: opening the verified course Next link directly...');
        window.location.assign(fallbackHref);
        scheduleClickNavigationVerify(key, sourceUrl, fallbackHref);
        return;
      } catch (e) {
        // Fall through to the event click path if direct navigation is blocked.
      }
    }

    try {
      clickTarget.scrollIntoView({ behavior: 'auto', block: 'center', inline: 'center' });
      updateOverlay('Auto Next: Next button detected. Clicking in the same tab...');

      // Keep navigation in the current tab even if the LMS link uses a target attribute.
      if (clickTarget instanceof HTMLAnchorElement) {
        clickTarget.setAttribute('target', '_self');
      }

      // Click immediately. If the LMS ignores the first click, a guarded one-time
      // verification fallback below opens the same Next link or retries the same control.
      dispatchTrustedLikeClick(clickTarget);
      scheduleClickNavigationVerify(key, sourceUrl, fallbackHref);
    } catch (e) {
      updateOverlay('Auto Next: click failed. Retrying detection...');
    } finally {
      currentlyClicking = false;
      if (enabled) scheduleLoop(CHECK_MS);
    }
  }

  function pauseAutoNext() {
    if (!enabled) return;
    manualPaused = true;
    setSessionManualPaused(true);
    clearLoop();
    clearPendingClick();
    currentlyClicking = false;
    updateOverlay('Auto Next: manually PAUSED. Use Resume to continue, or Force Next for one manual Next click.');
  }

  function resumeAutoNext() {
    if (!enabled) return;
    manualPaused = false;
    setSessionManualPaused(false);
    lastTickAt = Date.now();
    clearPendingClick();
    updateOverlay('Auto Next: RESUMED. Detecting Next button continuously.');
    scheduleLoop(0);
  }

  function pauseAfterFinalExamSubmit(reason = 'Final Exam submitted/completed. Auto detection PAUSED.') {
    if (!enabled) return;
    manualPaused = true;
    setSessionManualPaused(true);
    setFinalExamSubmitPending(false);
    clearLoop();
    clearPendingClick();
    currentlyClicking = false;
    quizState.autoSubmitInFlight = false;
    quizState.statusNote = reason;
    updateOverlay(reason);
  }

  function forceNextOnce() {
    if (!enabled || currentlyClicking) return;

    const next = findNextButton() || findForceNextButton();
    if (!next || !next.isConnected || !isVisible(next) || !isEnabled(next)) {
      updateOverlay('Force Next: no usable course Next control is visible right now. Nothing was clicked.');
      return;
    }

    currentlyClicking = true;
    clearPendingClick();
    const key = elementKey(next);
    lastClickedKey = key;
    lastClickedUrl = location.href;
    lastClickAt = Date.now();

    try {
      next.scrollIntoView({ behavior: 'auto', block: 'center', inline: 'center' });
      if (next instanceof HTMLAnchorElement) next.setAttribute('target', '_self');
      updateOverlay('Force Next: clicked Next once. Normal Auto Next routine will continue.');
      dispatchTrustedLikeClick(next);
      scheduleClickNavigationVerify(key, lastClickedUrl, validNavigationHref(next));
    } catch (e) {
      updateOverlay('Force Next: click failed. No second click was attempted.');
    } finally {
      currentlyClicking = false;
      if (enabled && !manualPaused) scheduleLoop(CHECK_MS);
    }
  }

  function mainLoopCore(forceImmediateClick = false) {
    if (!enabled || manualPaused || currentlyClicking) return;

    const now = Date.now();
    const slept = now - lastTickAt > LONG_PAUSE_MS;
    lastTickAt = now;

    if (location.href !== lastUrl) {
      lastUrl = location.href;
      lastClickedKey = '';
      lastClickedUrl = '';
      bottomWaitStartedAt = 0;
      clearPendingClick();
      resetPageTimerStart('url-changed', now, false);
      resetQuizState();
      updateOverlay('Auto Next: page changed. Detecting Next button...');
    } else if (slept) {
      clearPendingClick();
      // Do not restart the optional module timer after browser throttling/system wake.
      // A visible module may have continued its own countdown while the extension loop
      // was delayed; the extension timer must stay aligned with the document clock.
      if (nextTimerEnabled) {
        keepPageTimerSyncedToDocumentClock(now);
      } else {
        resetPageTimerStart('system-wake', now, false);
      }
      updateOverlay('Auto Next: system wake/long pause detected. Resuming detection...');
    }

    ensurePageTimerForCurrentView(now);

    if (!navigator.onLine) {
      clearPendingClick();
      updateOverlay('Auto Next: offline. Paused until the internet connection returns.');
      scheduleLoop(CHECK_MS);
      return;
    }

    const body = getBodyText();
    const path = normalizeText(location.pathname + ' ' + location.hash);
    const elements = visibleInteractiveElements();
    const elementTexts = elements.map(getElementText);
    const quizWords = /\b(quiz|quizzes|test|exam|assessment|question|questions)\b/.test(body) || /\b(quizzes|quiz|tests|test|exam|assessment)\b/.test(path);
    const zeroPointActivity = isZeroPointOrUngradedActivity();
    const elementText = elementTexts.join(' | ');
    const assessmentContext = detectAssessmentPageContext(body, path, elementTexts);
    const protectedAssessment = isProtectedAssessmentContext(assessmentContext);
    const skippableZeroPointActivity = zeroPointActivity || assessmentContext.zeroPoints;
    const finalExamPage = protectedAssessment && assessmentContext.kind === 'final-exam';
    const finalExamActive = assessmentContext.activeAttempt;
    const finalExamCompleted = finalExamPage && assessmentContext.completed;
    if (finalExamCompleted && (getFinalExamSubmitPending() || !finalExamActive)) {
      pauseAfterFinalExamSubmit('Final Exam submitted/completed. Auto detection PAUSED.');
      return;
    }

    if (skippableZeroPointActivity) {
      if (quizState.active) resetQuizState();
      updateOverlay('Auto Next: 0-point/ungraded activity detected. Auto-pause is skipped and normal Next detection continues.');
    } else if (protectedAssessment) {
      const quizSnapshot = createQuizSnapshot(body, path, elementTexts, quizWords);
      processQuizMonitor(quizSnapshot, now);
      if (quizState.autoSubmitInFlight) {
        clearPendingClick();
        scheduleLoop(CHECK_MS);
        return;
      }
    } else if (quizState.active) {
      resetQuizState();
    }

    const blockReason = findBlockingReason();
    if (blockReason) {
      clearPendingClick();
      bottomWaitStartedAt = 0;
      updateOverlay(blockReason);
      scheduleLoop(CHECK_MS);
      return;
    }

    // Some AOL/Canvas learning items unlock the course Next button only after their
    // own LMS wait countdown (for example, "Wait 18s to continue..."). That LMS
    // timer is mandatory even when the optional extension timer is OFF. Never use a
    // hard Next href or a cached button while this wait/unlock state is present.
    const lmsModuleWait = detectLmsModuleWait(body);
    if (lmsModuleWait.active && !protectedAssessment && !skippableZeroPointActivity) {
      clearPendingClick();
      bottomWaitStartedAt = 0;
      updateOverlay(describeLmsModuleWait(lmsModuleWait, now));
      scheduleLoop(Math.min(1000, CHECK_MS));
      return;
    }

    let next = findNextButton();
    if (!next) {
      if (hasDisabledLmsNextControl() && !protectedAssessment) {
        clearPendingClick();
        updateOverlay(nextTimerEnabled
          ? `Auto detection ON · Next is locked by the LMS. ${describeNextTimerSync(now)}. Waiting for unlock.`
          : 'Auto detection ON · Next is locked by the LMS. Waiting for unlock.');
        scheduleLoop(CHECK_MS);
        return;
      }
      const hardHref = getNextHrefFromDocument();
      if (hardHref) {
        bottomWaitStartedAt = 0;
        const deadline = getNextClickDeadline(now);
        const delayMs = Math.max(0, deadline - now);
        if (nextTimerEnabled && delayMs > 0) {
          if (!pendingNextClick || pendingNextClick.url !== location.href || pendingNextClick.href !== hardHref || pendingNextClick.deadline !== deadline) {
            clearPendingClick();
            pendingNextClick = {
              key: `href|${hardHref}`,
              href: hardHref,
              url: location.href,
              deadline,
              delayMs,
              delaySeconds: clampNextTimerSeconds(nextTimerSeconds),
              pageStartedAt: pageTimerStartedAt
            };
            updateOverlay(`Auto Next: hard Next link found. Waiting for synced module timer. ${describeNextTimerSync(now)}.`);
            clickTimer = setTimeout(() => {
              const planned = pendingNextClick;
              clickTimer = null;
              pendingNextClick = null;
              if (planned?.href && planned.url === location.href && enabled && !manualPaused) {
                try { window.location.assign(planned.href); } catch (e) { scheduleLoop(CHECK_MS); }
              }
            }, delayMs);
          }
          scheduleLoop(CHECK_MS);
          return;
        }
        updateOverlay('Auto Next: hard Next link found. Opening it directly...');
        try { window.location.assign(hardHref); return; } catch (e) {}
      }
      clearPendingClick();
      if (canScrollDown()) {
        bottomWaitStartedAt = 0;
        scrollDownStep();
        updateOverlay('Auto Next: detecting Next button and scrolling down...');
      } else {
        if (!bottomWaitStartedAt) bottomWaitStartedAt = now;
        updateOverlay('Auto Next: Next button not found yet. Continuous detection is running...');
      }
      scheduleLoop(CHECK_MS);
      return;
    }

    bottomWaitStartedAt = 0;
    next.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });

    const key = elementKey(next);
    const clickedSameTargetRecently =
      key === lastClickedKey &&
      location.href === lastClickedUrl &&
      now - lastClickAt < SAME_TARGET_REPEAT_MS;

    if (clickedSameTargetRecently || now - lastClickAt < CLICK_COOLDOWN_MS) {
      updateOverlay('Auto Next: waiting for the page to change after the last click...');
      scheduleLoop(CHECK_MS);
      return;
    }

    if ((forceImmediateClick || document.visibilityState === 'hidden') && !nextTimerEnabled) {
      clearPendingClick();
      updateOverlay('Auto Next: Next button detected in background. Clicking now...');
      clickNext(next);
      return;
    }

    const deadline = getNextClickDeadline(now);
    const delayMs = Math.max(0, deadline - now);

    if (nextTimerEnabled && delayMs <= 0) {
      clearPendingClick();
      updateOverlay('Auto Next: synced module timer complete. Clicking Next now...');
      clickNext(next);
      return;
    }

    if (clickTimer && pendingNextClick) {
      if (pendingNextClick.key !== key || pendingNextClick.url !== location.href || pendingNextClick.deadline !== deadline) {
        clearPendingClick();
      } else {
        const countdown = nextTimerCountdownText(now);
        updateOverlay(nextTimerEnabled
          ? `Auto Next: Next button detected. Synced module timer active. ${countdown} remaining...`
          : 'Auto Next: Next button detected. Preparing click...');
        scheduleLoop(CHECK_MS);
        return;
      }
    }

    if (!clickTimer) {
      if (!nextTimerEnabled || delayMs <= 0) {
        clearPendingClick();
        updateOverlay(nextTimerEnabled
          ? 'Auto Next: synced module timer complete. Clicking Next now...'
          : 'Auto Next: Next button detected. Preparing click...');
        clickNext(next);
        return;
      }

      pendingNextClick = {
        key,
        url: location.href,
        deadline,
        delayMs,
        delaySeconds: clampNextTimerSeconds(nextTimerSeconds),
        pageStartedAt: pageTimerStartedAt
      };
      updateOverlay(`Auto Next: Next button detected. Synced module timer active. ${describeNextTimerSync(now)}.`);
      clickTimer = setTimeout(() => {
        const planned = pendingNextClick;
        clickTimer = null;
        pendingNextClick = null;
        safeInvoke('delayed Next click', () => {
          if (!planned || planned.url !== location.href) return;
          const currentWait = detectLmsModuleWait();
          if (currentWait.active) {
            updateOverlay(describeLmsModuleWait(currentWait));
            scheduleLoop(CHECK_MS);
            return;
          }
          const freshNext = findNextButton();
          if (!freshNext) {
            const hardHref = getNextHrefFromDocument();
            if (hardHref) {
              updateOverlay('Auto Next: synced timer finished. Opening verified hard Next link...');
              try { window.location.assign(hardHref); return; } catch (e) {}
            }
            updateOverlay('Auto Next: timer finished, but the Next control disappeared. Re-scanning...');
            scheduleLoop(CHECK_MS);
            return;
          }
          // Always click the fresh live DOM control, not the element captured when the
          // countdown started. Canvas/AOL can re-render footer controls while the timer runs.
          clickNext(freshNext);
        });
      }, delayMs);
    }

    scheduleLoop(CHECK_MS);
  }

  function mainLoop(forceImmediateClick = false) {
    if (pageSuspended || !enabled || manualPaused || currentlyClicking) return;

    try {
      mainLoopCore(forceImmediateClick);
      consecutiveLoopErrors = 0;
    } catch (error) {
      consecutiveLoopErrors += 1;
      currentlyClicking = false;
      clearPendingClick();

      const now = Date.now();
      if (now - lastLoopRecoveryNoticeAt > 2000) {
        lastLoopRecoveryNoticeAt = now;
        safeInvoke('recovery overlay', () => updateOverlay(
          'Auto Next: temporary LMS page change detected. Re-synchronizing automatically...'
        ));
      }

      // DOM frameworks can replace quiz/navigation nodes between reads. Treat a thrown
      // read as transient, back off slightly, and rescan from the live page instead of
      // letting one page mutation stop the extension.
      if (enabled && !manualPaused && !pageSuspended) {
        scheduleLoop(Math.min(1500, 300 + (consecutiveLoopErrors * 150)));
      }
      console.warn(`[Auto Next Detector] recovered loop error: ${errorText(error)}`);
    }
  }

  function registerEnabledTab() {
    safeRuntimeMessage({ type: 'AUTO_NEXT_DETECTOR_REGISTER_TAB' });
  }

  function unregisterEnabledTab() {
    safeRuntimeMessage({ type: 'AUTO_NEXT_DETECTOR_UNREGISTER_TAB' });
  }

  function startAutoNext(preserveManualPause = false) {
    enabled = true;
    manualPaused = preserveManualPause ? getSessionManualPaused() : false;
    if (!preserveManualPause) setSessionManualPaused(false);
    lastTickAt = Date.now();
    lastUrl = location.href;
    resetPageTimerStart('start-on-tab-navigation-sync', lastTickAt, true);
    currentlyClicking = false;
    startActivityControlPresent = false;
    clearPendingClick();
    createOverlay();
    setSessionEnabled(true);
    registerEnabledTab();

    if (getFinalExamSubmitPending()) {
      pauseAfterFinalExamSubmit('Final Exam submission completed/navigation changed. Auto detection PAUSED.');
      return;
    }

    if (manualPaused) {
      updateOverlay('Auto Next: manually PAUSED. Use Resume to continue, or Force Next for one manual Next click.');
      return;
    }

    updateOverlay(document.visibilityState === 'hidden'
      ? 'Auto Next: ON. Background detection active.'
      : 'Auto Next: ON. Detecting Next button continuously.');
    scheduleLoop(150);
  }

  function stopAutoNext(reason = 'Stopped') {
    enabled = false;
    manualPaused = false;
    clearLoop();
    clearPendingClick();
    currentlyClicking = false;
    startActivityControlPresent = false;
    setSessionEnabled(false);
    setSessionManualPaused(false);
    setFinalExamSubmitPending(false);
    unregisterEnabledTab();
    resetQuizState();
    removeOverlay();
    message = reason;
    console.log('[Auto Next Detector]', reason);
  }

  window.addEventListener('online', () => safeInvoke('online event', () => {
    if (enabled) {
      recoverAfterLifecycleInterruption('online');
    }
  }));

  window.addEventListener('offline', () => safeInvoke('offline event', () => {
    if (enabled) {
      clearPendingClick();
      updateOverlay('Auto Next: offline. Paused.');
    }
  }));

  document.addEventListener('visibilitychange', () => safeInvoke('visibility event', () => {
    if (!enabled) return;
    if (document.visibilityState === 'visible') {
      recoverAfterLifecycleInterruption('visible');
    } else {
      lastTickAt = Date.now();
      clearPendingClick();
      updateOverlay('Auto Next: background mode active. Detection will continue.');
    }
    if (manualPaused) {
      updateOverlay('Auto Next: manually PAUSED. Use Resume to continue, or Force Next for one manual Next click.');
    }
  }));

  window.addEventListener('resize', () => safeInvoke('window resize', () => {
    if (overlay) {
      clampOverlayToViewport();
      saveOverlayGeometry();
      scheduleOverlayResponsiveLayout();
    }
  }));

  window.addEventListener('focus', () => safeInvoke('window focus', () => {
    if (enabled) recoverAfterLifecycleInterruption('focus');
  }));

  window.addEventListener('pagehide', () => safeInvoke('page suspend', () => {
    pageSuspended = true;
    clearLoop();
    clearPendingClick();
    currentlyClicking = false;
    if (overlayResponsiveRaf) {
      cancelAnimationFrame(overlayResponsiveRaf);
      overlayResponsiveRaf = null;
    }
    if (overlayAutoFitRaf) {
      cancelAnimationFrame(overlayAutoFitRaf);
      overlayAutoFitRaf = null;
    }
  }));

  window.addEventListener('pageshow', () => safeInvoke('page resume', () => {
    if (enabled) recoverAfterLifecycleInterruption('pageshow');
  }));

  document.addEventListener('resume', () => safeInvoke('document resume event', () => {
    if (enabled) recoverAfterLifecycleInterruption('resume');
  }));

  document.addEventListener('freeze', () => safeInvoke('document freeze event', () => {
    pageSuspended = true;
    clearLoop();
    clearPendingClick();
    currentlyClicking = false;
  }));

  loadNextTimerSetting();
  if (globalThis.chrome?.storage?.onChanged?.addListener) {
    chrome.storage.onChanged.addListener((changes, areaName) => safeInvoke('settings update', () => {
      if (areaName !== 'local') return;
      if (changes?.[NEXT_TIMER_ENABLED_KEY] || changes?.[NEXT_TIMER_SECONDS_KEY]) {
        applyNextTimerSetting(
          changes?.[NEXT_TIMER_ENABLED_KEY]?.newValue ?? nextTimerEnabled,
          changes?.[NEXT_TIMER_SECONDS_KEY]?.newValue ?? nextTimerSeconds
        );
        clearPendingClick();
        if (enabled && !manualPaused) {
          resetPageTimerStart('timer-setting-changed', Date.now(), true);
          updateOverlay(`Auto Next: ${nextTimerStatusText()}. Detecting Next button continuously.`);
          scheduleLoop(0);
        }
      }
    }));
  }


  document.addEventListener('input', () => safeInvoke('quiz input event', () => {
    if (enabled && !manualPaused && quizState.active) scheduleLoop(0);
  }), true);

  document.addEventListener('change', () => safeInvoke('quiz change event', () => {
    if (enabled && !manualPaused && quizState.active) scheduleLoop(0);
  }), true);

  const observer = new MutationObserver(mutations => safeInvoke('LMS mutation observer', () => {
    if (currentlyClicking || pageSuspended) return;

    // Ignore our own overlay updates. Capture quiz/final-exam start-page duration even
    // while Auto Next is not yet enabled, so the same tab can reuse that authoritative
    // LMS metadata after the manual attempt opens.
    const hasExternalMutation = mutations.some(mutation =>
      !(overlay && (mutation.target === overlay || overlay.contains(mutation.target)))
    );
    if (!hasExternalMutation) return;

    scheduleActivityMetadataCapture(120);
    if (enabled && !manualPaused) scheduleLoop(0);
  }));
  safeInvoke('mutation observer startup', () => {
    observer.observe(document, { childList: true, subtree: true, attributes: true });
  });

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    try {
      if (!msg || typeof msg.type !== 'string') return false;
      if (msg.type === 'AUTO_NEXT_DETECTOR_START') {
        startAutoNext();
        sendResponse({ ok: true, enabled, manualPaused, message });
        return false;
      }
      if (msg.type === 'AUTO_NEXT_DETECTOR_STOP') {
        stopAutoNext('Stopped from popup');
        sendResponse({ ok: true, enabled: false, message: 'Stopped' });
        return false;
      }
      if (msg.type === 'AUTO_NEXT_DETECTOR_STATUS') {
        sendResponse({ ok: true, enabled, manualPaused, message });
        return false;
      }
      if (msg.type === 'AUTO_NEXT_DETECTOR_WATCHDOG_TICK') {
        if (enabled && !manualPaused && !currentlyClicking && !pageSuspended) {
          lastTickAt = Date.now();
          clearPendingClick();
          mainLoop(true);
        }
        sendResponse({ ok: true, enabled, manualPaused, message });
        return false;
      }
      return false;
    } catch (error) {
      if (!isExpectedTransientError(error)) {
        console.warn(`[Auto Next Detector] runtime message recovered: ${errorText(error)}`);
      }
      try {
        sendResponse({ ok: false, enabled, manualPaused, message: 'Temporary page transition detected; recovery is automatic.' });
      } catch (sendError) {}
      if (enabled && !manualPaused && !pageSuspended) scheduleLoop(300);
      return false;
    }
  });

  // Lightweight metadata capture runs regardless of Auto Next ON/OFF. This lets a
  // manually opened Final Exam carry its start-page time limit into the active attempt.
  scheduleActivityMetadataCapture(0);
  document.addEventListener('DOMContentLoaded', () => scheduleActivityMetadataCapture(0), { once: true });
  setTimeout(() => scheduleActivityMetadataCapture(0), 1000);
  setTimeout(() => scheduleActivityMetadataCapture(0), 3000);

  let restoredFromSession = false;
  safeInvoke('session restore', () => {
    if (window.sessionStorage.getItem(SESSION_ENABLED_KEY) === '1') {
      restoredFromSession = true;
      startAutoNext(true);
    }
  });

  safeRuntimeMessage({ type: 'AUTO_NEXT_DETECTOR_QUERY_TAB' }, response => {
    if (response?.ok && response.enabled && !enabled) {
      safeInvoke('tab-state restore', () => startAutoNext(true));
    } else if (restoredFromSession && enabled) {
      registerEnabledTab();
    }
  });
})();
