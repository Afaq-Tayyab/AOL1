const statusEl = document.getElementById('status');
const startBtn = document.getElementById('start');
const stopBtn = document.getElementById('stop');
const timerToggleBtn = document.getElementById('timerToggle');
const timerSecondsInput = document.getElementById('timerSeconds');
const saveTimerBtn = document.getElementById('saveTimer');
const NEXT_TIMER_ENABLED_KEY = 'autoNextDetectorNextTimerEnabled';
const NEXT_TIMER_SECONDS_KEY = 'autoNextDetectorNextTimerSeconds';
const MAX_NEXT_TIMER_SECONDS = 2147483;

let statusRequestRunning = false;
let statusTimer = null;
let nextTimerEnabled = false;
let nextTimerSeconds = 1;

function errorText(error) {
  return String(error?.message || error || 'Temporary extension communication error');
}

function isExpectedTransientError(error) {
  return /receiving end does not exist|could not establish connection|message port closed|asynchronous response.*channel closed|extension context invalidated|context invalidated|tab was closed|no tab with id|network|interrupted|aborted/i.test(errorText(error));
}

window.addEventListener('unhandledrejection', event => {
  if (isExpectedTransientError(event?.reason)) event.preventDefault?.();
});
window.addEventListener('error', event => {
  const reason = event?.error || event?.message;
  if (isExpectedTransientError(reason)) event.preventDefault?.();
});

function clampNextTimerSeconds(value) {
  const parsed = Math.floor(Number(value));
  if (!Number.isFinite(parsed) || parsed < 1) return 1;
  return Math.min(parsed, MAX_NEXT_TIMER_SECONDS);
}

function renderTimerSetting() {
  if (timerToggleBtn) {
    timerToggleBtn.dataset.enabled = nextTimerEnabled ? '1' : '0';
    timerToggleBtn.textContent = nextTimerEnabled ? `Next Timer: ON (${nextTimerSeconds} sec)` : 'Next Timer: OFF';
    timerToggleBtn.setAttribute('aria-pressed', nextTimerEnabled ? 'true' : 'false');
  }
  if (timerSecondsInput) timerSecondsInput.value = String(nextTimerSeconds);
}

async function loadSettings() {
  try {
    const data = await chrome.storage.local.get([NEXT_TIMER_ENABLED_KEY, NEXT_TIMER_SECONDS_KEY]);
    nextTimerEnabled = data?.[NEXT_TIMER_ENABLED_KEY] === true;
    nextTimerSeconds = clampNextTimerSeconds(data?.[NEXT_TIMER_SECONDS_KEY] ?? 1);
  } catch (error) {
    nextTimerEnabled = false;
    nextTimerSeconds = 1;
  }
  renderTimerSetting();
}

async function saveTimerSetting({ toggle = false } = {}) {
  const previousEnabled = nextTimerEnabled;
  const previousSeconds = nextTimerSeconds;
  if (toggle) nextTimerEnabled = !nextTimerEnabled;
  nextTimerSeconds = clampNextTimerSeconds(timerSecondsInput?.value ?? nextTimerSeconds);
  renderTimerSetting();
  try {
    await chrome.storage.local.set({
      [NEXT_TIMER_ENABLED_KEY]: nextTimerEnabled,
      [NEXT_TIMER_SECONDS_KEY]: nextTimerSeconds
    });
    statusEl.textContent = nextTimerEnabled
      ? `Next Timer saved: ON (${nextTimerSeconds} sec).\nAuto Next will wait before clicking normal course Next buttons.`
      : `Next Timer saved: OFF.\nAuto Next will use normal fast Next detection.`;
  } catch (error) {
    nextTimerEnabled = previousEnabled;
    nextTimerSeconds = previousSeconds;
    renderTimerSetting();
    statusEl.textContent = 'Timer setting could not be saved. Please reopen the extension and try again.';
  }
}

async function getActiveTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab || null;
  } catch (error) {
    return null;
  }
}

async function sendMessageToActiveTab(message) {
  const tab = await getActiveTab();
  if (!tab?.id) return { ok: false, error: 'Open your course page, reload it, then try again.' };
  try {
    return await chrome.tabs.sendMessage(tab.id, message);
  } catch (error) {
    return {
      ok: false,
      error: 'Content script is temporarily unavailable on this page. Reload your AOL course page and try again.'
    };
  }
}

function renderStatus(response) {
  if (response?.ok) {
    const timerLine = nextTimerEnabled ? `\nNext Timer: ON (${nextTimerSeconds} sec)` : '\nNext Timer: OFF';
    statusEl.textContent = response.enabled
      ? `${response.manualPaused ? 'Status: PAUSED' : 'Status: ON'}\n${response.message || 'Detecting Next button...'}${timerLine}`
      : `Status: OFF${response.message ? `\n${response.message}` : ''}${timerLine}`;
    return;
  }
  statusEl.textContent = response?.error || 'Open your course page, reload it, then try again.';
}

async function loadStatus() {
  if (statusRequestRunning || document.visibilityState === 'hidden') return;
  statusRequestRunning = true;
  try {
    renderStatus(await sendMessageToActiveTab({ type: 'AUTO_NEXT_DETECTOR_STATUS' }));
  } catch (error) {
    renderStatus({ ok: false, error: errorText(error) });
  } finally {
    statusRequestRunning = false;
  }
}

startBtn.addEventListener('click', async () => {
  try {
    renderStatus(await sendMessageToActiveTab({ type: 'AUTO_NEXT_DETECTOR_START' }));
  } catch (error) {
    renderStatus({ ok: false, error: errorText(error) });
  }
});

timerToggleBtn?.addEventListener('click', () => { void saveTimerSetting({ toggle: true }); });
saveTimerBtn?.addEventListener('click', () => { void saveTimerSetting({ toggle: false }); });
timerSecondsInput?.addEventListener('change', () => { timerSecondsInput.value = String(clampNextTimerSeconds(timerSecondsInput.value)); });

stopBtn.addEventListener('click', async () => {
  try {
    renderStatus(await sendMessageToActiveTab({ type: 'AUTO_NEXT_DETECTOR_STOP' }));
  } catch (error) {
    renderStatus({ ok: false, error: errorText(error) });
  }
});

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible') {
    void loadSettings();
    void loadStatus();
  }
});

window.addEventListener('pagehide', () => {
  if (statusTimer) clearInterval(statusTimer);
  statusTimer = null;
});

void loadSettings().then(() => loadStatus());
statusTimer = setInterval(() => { void loadStatus(); }, 2000);
