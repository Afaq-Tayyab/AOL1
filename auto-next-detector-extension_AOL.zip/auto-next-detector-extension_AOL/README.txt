Auto Next Detector v2.1.6

V2.1.6 LMS WAIT COUNTDOWN FIX
- Detects AOL/Canvas module wait text such as "Wait 18s to continue...".
- When the extension timer is OFF, the extension waits for the LMS countdown/unlock before clicking Next.
- When the extension timer is ON, Next clicks only after BOTH the user timer and the LMS wait/unlock are complete.
- Disabled Next buttons and hard Next hrefs are not used while the LMS wait is active.
- Audio remains fully removed to avoid Chrome AudioContext/autoplay errors after sleep/lid down.

Auto Next Detector v2.1.4

- Audio/reminder sounds have been fully removed to eliminate Chrome AudioContext/autoplay errors after sleep, hibernation, lid close, internet disconnect, or service-worker wake.
- Quiz / Online Exam / Final Exam detection, protected graded pause, 0-point skip, hard content Next navigation, module-synced Next timer, 55% LMS-time submit guard, Force Next, responsive panel, and default hidden quiz details remain active.
- Quiz/Exam details stay hidden by default; use Show to view live progress.

Install: remove older versions completely, extract this ZIP, then Load unpacked in chrome://extensions.

Auto Next Detector v2.1.3
v2.1.3 MESSENGER-STYLE SINGLE SOUND UPDATE
V2.1.3 SOUND UPDATE
- Replaced the old reminder alarm WAV with a single original Messenger-style pop/chime tone.
- Updated Web Audio fallback warning/submit tones to the same soft double-pop style.
- Sounds ON/OFF setting remains unchanged.
- The extension does not bundle the official Facebook/Messenger copyrighted sound file; this is a clean synthesized notification tone with a similar feel.
- Optional Next Timer now stays anchored to the LMS document/page load clock.
- The live header badge counts down from the configured seconds immediately with the module/page, not only after the Next button becomes enabled.
- Dynamic AOL/Canvas text such as “Wait 8s to continue...” no longer restarts the extension timer back to 30 seconds.
- Browser throttling, tab sleep, and LMS re-render recovery no longer reset the optional Next Timer.
- When Timer is ON, Next remains hard-gated until the synced countdown reaches 0 and a valid non-assessment Next control is available.
================================

Main navigation
- Continuously detects the LMS course Next control and clicks it in the same tab.
- Quiz/test/manual work blocks normal course Next navigation while the activity is active.
- Exact Final Exam and Online Exam are live monitored timed activities. Practical Exam / Final Exam Practical is identified separately and stays manual-only.
- 0-point or explicitly ungraded ordinary activities do not pause normal Next detection. Positively identified Final/Online or Practical Exams remain protected even if ungraded/0-point, because a required practical component can be unmarked.
- Force Next is manual one-click only: one button press causes at most one Next click.

Quiz vs Final Exam detection
- The visible LMS activity title plus positive LMS assessment evidence distinguish Module Quizzes, Online/Final Exams, Practical Exams, and ordinary read-only content.
- The live panel heading shows QUIZ STARTED or FINAL EXAM STARTED.
- Both use the same fail-closed live LMS question and timer synchronization.
- After a Final Exam is submitted, Auto Next automatically enters PAUSED state so it cannot continue course navigation by itself.

Live LMS question sync
- Re-scans current activity question blocks from top to bottom every detection cycle.
- Re-reads answer controls and LMS question navigation instead of freezing old counts.
- AOL/Canvas question-navigation ? / check state has priority when it is explicit.
- Shows total questions, attempted questions, remaining questions, and missed question numbers.
- Auto-submit is blocked if total question count or individual answer states are not reliably confirmed.

LMS timer sync and 55% rule
- No independent extension quiz/exam clock is used.
- The visible AOL/Canvas Time Running value is read live on every scan. On the user's AOL Classic Quiz pages it is a countdown/remaining-time value (for example a new 30-minute quiz shows about 29:xx; after 59 minutes of a 3-hour exam it shows about 2:01:xx).
- The extension does not blindly trust the label. It observes real Time Running movement: two downward ticks confirm remaining/countdown mode; two upward ticks confirm elapsed mode. Auto-submit stays blocked until direction is confirmed.
- Once direction is confirmed, the panel derives and shows synchronized Elapsed, Remaining, and Total time from the same live LMS value.
- Auto-submit eligibility begins only when 45% of total time remains, which equals 55% spent.
  30 min -> 13:30 remaining / 16:30 spent
  60 min -> 27:00 remaining / 33:00 spent
  120 min -> 54:00 remaining / 66:00 spent
  180 min -> 81:00 remaining / 99:00 spent
- The threshold requires both normalized sides of the same LMS clock to agree: elapsed >= 55% and remaining <= 45%.
- Before submitting, the extension requires confirmed timer direction, consecutive plausible live timer reads, real timer movement, a confirmed total question count, confirmed answer state for every question, and zero missed questions.
- Submit is clicked once. A visible submit-confirmation control can also be clicked once.
- If any safety condition is missing, auto-submit remains blocked.
- Final Exam/Online Exam auto-submit uses the same 55%-spent safety rule; after submission, Auto Next pauses automatically.

Live details Hide / Show
- Hide/Show appears in the top-right of the panel only while a Quiz or Final Exam is actively monitored.
- Click Hide once to hide the status text, live question/timer card, Stop, Force Next, and extra controls.
- The panel automatically becomes small and leaves only Pause while detection is running.
- If Pause is pressed in hidden mode, Resume replaces it so the extension can be continued.
- Click Show to restore the full live details and full controls.
- Hiding the UI does not change question scanning, LMS timer sync, warning logic, or the 55%-spent submit guard.

Idle responsive panel
- When no live Quiz/Final Exam data is active, the panel auto-collapses to header + Resume/Pause/Stop/Force Next.
- Drag the title bar to move the panel.
- Manual bottom-right resizing still progressively reduces the visible controls.

Quiz / Final Exam arrival reminder
- When a genuine Quiz/Test or Final Exam start control first appears, the extension plays one short single reminder alarm.
- The alarm fires once for that start-page appearance; the 250 ms detector does not replay it every scan.
- Active attempts do not trigger the arrival alarm again.
- Ordinary 0-point/ungraded activities remain excluded from pause/reminder. Positively identified Final/Online or Practical Exams remain protected even if ungraded.
- The arrival sound is played from a Chrome offscreen extension document so it is not dependent on the quiz page Web Audio context being unlocked.

Warnings
- At 20% elapsed with 0 LMS-confirmed attempted questions, a warning is shown and a tone is attempted.
- If progress stops while unanswered questions remain, a reminder is shown/tone attempted.
- Page-based warning tones may still be subject to browser audio restrictions until a user click or key press.

Install
1. Extract the ZIP.
2. Open chrome://extensions.
3. Disable/remove the older Auto Next Detector version.
4. Turn Developer mode ON.
5. Click Load unpacked.
6. Select the extracted auto-next-detector-extension_AOL folder.
7. Reload the AOL course page.
8. Open the extension and click Start on this tab.

Safety note
The auto-submit path is intentionally fail-closed. If the live LMS timer, supported total duration,
question count, or answer state cannot be confirmed, the extension will not auto-submit.


v1.9.5 RELIABILITY / SELF-HEALING UPDATE
----------------------------------------
- Service-worker message races during LMS navigation, tab teardown, sleep/wake, and alarm startup are handled as transient lifecycle events instead of unchecked extension errors.
- Enabled-tab storage updates are serialized so simultaneous register/unregister operations do not overwrite each other.
- The watchdog is created idempotently and every watchdog tab message is guarded.
- Offscreen reminder-audio creation and playback are serialized and retried safely without repeating Next/Submit actions.
- The content detection loop is wrapped in a recovery boundary. If the LMS replaces DOM nodes mid-scan, the loop clears any pending click, backs off briefly, and re-scans the live page automatically.
- Page hide/show, focus, visibility, resize, MutationObserver, ResizeObserver, quiz input/change, delayed Next clicks, and submit confirmation callbacks are guarded so one temporary page transition does not stop the extension.
- Popup status polling no longer overlaps and handles popup/page lifecycle changes cleanly.
- Existing quiz/final-exam logic and one-click Force Next behavior remain unchanged.

IMPORTANT: Chrome's “Inspect views: service worker” text is normal for Manifest V3 extensions. The red “Errors” button means Chrome logged an extension error. Install v2.1.3 as a fresh unpacked extension and remove/disable the older v1.9.2/v1.9.4 copy so old stored errors are not confused with the new build.


v1.9.7 LEGACY FINAL EXAM TIMER CHANGE (SUPERSEDED BY v2.1.3)
- Historical note: v1.9.7 treated AOL/Canvas "Time Running" as elapsed time. v2.1.3 replaces that assumption with live direction detection and confirms the user's AOL countdown behavior.
- Remaining time is derived only after the LMS total time limit is independently confirmed.
- Supports 30/60/120/180 minute limits written in minutes or as 0.5/1/2/3 hours.
- Start-page LMS duration metadata is cached in the same tab even before Auto Next is enabled.
- When an active attempt lacks a visible time limit, the extension can conservatively read the same-origin referrer/start page and reuse the duration only when the activity title/type matches exactly.
- Time Running alone can never invent a total duration or trigger auto-submit.
- Auto-submit requires real timer movement and Final Exam monitoring for at least 3.5 seconds before a submit can be armed.
- 55% spent / 45% remaining guard and all-question confirmation remain mandatory.


v1.9.7 ONLINE EXAM + MODULE QUIZ CLASSIFICATION
- AOL activity title scanning now scores all relevant visible LMS headings instead of taking the first generic H1/H2.
- Exact "Online Exam" is classified as the final-assessment type and uses the Final Exam safety behavior.
- "Module <any number> Quiz" is explicitly recognized as a Quiz (for example Module 1, 5, 7, 9, 10, 12, 15, 19, or any other positive module number).
- Generic Quiz/Test/Assessment titles continue to be monitored as quiz activities.
- Online Exam and all quizzes use the same guarded 55%-spent / 45%-remaining auto-submit rule.
- Online Exam uses final-assessment post-submit Auto Pause, matching Final Exam behavior.
- Start-page duration cache and exact-title/type previous-page recovery remain mandatory; Time Running alone never invents a total duration.


v1.9.9 DOUBLE-EVIDENCE CONTENT / ASSESSMENT CLASSIFIER + SOUND TOGGLE
-----------------------------------------------------------------------
- Read-only syllabus, overview, course-component, and informational Pages are no longer classified from incidental words such as Module Quiz, Final Exam, graded assessment, or 40 questions.
- A real assessment now requires positive LMS evidence: active question/timer UI, a genuine Start/Take control, assessment route/result evidence, or structured Time Limit + Points/Questions/Attempts metadata paired with an assessment title.
- Syllabus/content pages continue to the real course Next control.
- Module <any number> Quiz remains a quiz. Online Exam and exact Final Exam remain final assessments. Practical Exam / Final Exam Practical is identified separately and is manual-only; the 55% auto-submit path does not run for practical assessments.
- Completed/result detection no longer treats generic prose such as "graded assessments" as a submitted Final Exam.
- Popup adds Sounds: ON (loud) / OFF (silent). OFF suppresses arrival alarms, stalled-progress warnings, 20% warnings, and submit tones while leaving all detection and navigation logic unchanged.


v1.9.9 LEGACY timer-threshold change (SUPERSEDED BY v2.1.3)
- Historical note: v1.9.9 used the LMS elapsed interpretation directly; v2.1.3 instead validates raw Time Running direction and cross-checks both elapsed and remaining time.
- A 30-minute quiz becomes eligible at 16:30 elapsed (13:30 remaining), not before.
- Live timer validation tracks elapsed rising and remaining falling together.
- Assessment state no longer resets because an LMS heading candidate changes during auto-save/re-render.
- Threshold status is recomputed from the current LMS clock every scan so stale blocker text cannot remain on screen.


v2.1.3 TIME RUNNING DIRECTION / 55% SUBMIT CORRECTION
--------------------------------------------------------
- Fixes the AOL countdown inversion visible in v1.9.9: Time Running 4:37 on a 30-minute quiz is interpreted as 4:37 REMAINING and 25:23 ELAPSED after downward timer movement is confirmed.
- Time Running is no longer permanently hard-coded as elapsed. Two real moving ticks determine whether the field counts down or up.
- Auto-submit cannot arm while timer direction is unknown.
- 55% eligibility is cross-checked from both live elapsed and live remaining values.
- Exact screenshot scenario: 30-minute quiz, 5/5 answered, Time Running 4:37 countdown -> threshold passed; after direction validation the Submit Quiz control is clicked once.
- Early scenario: 30-minute quiz, Time Running 25:23 countdown -> only 4:37 spent; no submit.


V2.0.1 OPTIONAL NEXT TIMER
- Added popup option: Next Timer ON/OFF.
- Set timer from 1 second upward.
- When ON, Auto Next waits the selected seconds after finding a normal course Next button, then clicks once.
- When OFF, normal fast Auto Next behavior is unchanged.
- This optional Next timer does not change Quiz/Online Exam 55% LMS auto-submit timing.


v2.1.3 adds a live panel countdown for the optional normal-course Next timer.

v2.1.3 CLEAN COUNTDOWN PANEL UPDATE
- Keeps the live Next countdown only in the header badge (for example, "Next in 7s").
- Removes the repeated body line "Timer ON Next click countdown..." from the compact panel.
- The body now stays clean as "Auto detection ON" while the timer continues working in the background.


v2.1.3 GRADED-ONLY PAUSE + HARDENED NEXT RECOVERY
- Explicit 0 Points Possible / ungraded activities now always behave like normal course content and Auto Next continues to the course Next button. This includes 0-point assignments and 0-point quiz-like pages.
- Real assessment pause is reserved for actual graded quiz/exam surfaces. AOL/Canvas point metadata such as Points 5, Points 40, 1 pts, or 5 Points Possible is treated as positive graded evidence.
- If a page contains assignment submission UI or informational assessment wording but also exposes a valid course Next control, Auto Next will prefer the course Next path instead of pausing unnecessarily.
- Next navigation recovery is stronger: after the countdown ends the extension clicks the fresh live Next control, then verifies navigation faster. If the page does not change, it opens the current Next link directly or retries the current Next control once, even if Canvas/AOL re-rendered the footer and the element identity changed.
- Pointer, mouse, focus, and click events are dispatched for LMS controls to reduce missed clicks on dynamic Canvas/AOL pages.


v2.1.3: Hard Next navigation for ordinary content/pages, stronger protected-assessment-only pause, assignment/practice pages continue unless they are real graded quizzes/exams, and 0-point activities continue to skip.


Version 2.1.3 update:
- Next Timer is now module/page-time synced instead of starting only when the Next button is detected.
- If the page has already been open for 10 seconds and the timer is set to 30 seconds, only 20 seconds remain.
- If the LMS reveals the Next button after 20 seconds on a 30-second timer, Auto Next waits only the final 10 seconds.
- Timer ON is a hard gate: normal content Next will not be clicked until the synced timer reaches zero, including watchdog/background recovery paths.
- Quiz, Online Exam, Final Exam, Practical Exam pause/submit protections remain unchanged.


V2.1.3 update:
- Sleep/lid close/hibernation/offline recovery hardening added.
- Known Chrome transient lifecycle errors are consumed and the watchdog safely re-registers the tab.
- Quiz/Online Exam/Final Exam live details are hidden by default; use the Show button to view them.
